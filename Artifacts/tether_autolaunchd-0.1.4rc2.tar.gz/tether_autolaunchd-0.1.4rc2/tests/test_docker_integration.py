from __future__ import annotations

from pathlib import Path

from tether_autolaunchd.docker_integration import (
    direct_real_docker_bdd_command,
    load_docker_integration_config,
    plan_docker_bdd,
    plan_mock_docker_bdd,
    plan_real_docker_bdd,
)
from tether_autolaunchd.publish import debian_package_version


def _package_deb_path() -> str:
    root = Path(__file__).resolve().parents[1]
    version_line = next(
        line
        for line in (root / "src" / "tether_autolaunchd" / "__init__.py")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.startswith("__version__ = ")
    )
    version = version_line.split('"', 2)[1]
    return f"dist/tether-autolaunchd_{debian_package_version(version)}_all.deb"


def test_load_docker_integration_config_uses_safe_defaults(tmp_path: Path) -> None:
    config = load_docker_integration_config(env={}, workspace_dir=tmp_path)

    assert config.project_name == "tether-autolaunchd-itest"
    assert config.compose_file == (tmp_path / "docker-compose.mock.yml").resolve()
    assert config.base_image == "python:3.11-slim"
    assert config.mock_mode is True
    assert config.tether_image is None
    assert config.pytest_target == "tests/test_bdd_docker_integration.py"
    assert config.fake_tether is False
    assert config.fake_sessions == ("codexA",)


def test_plan_mock_docker_bdd_is_deterministic(tmp_path: Path) -> None:
    config = load_docker_integration_config(
        env={
            "TAD_DOCKER_PROJECT": "demo-itest",
            "TAD_DOCKER_BASE_IMAGE": "python:3.12-slim",
            "TAD_DOCKER_PYTEST_TARGET": "tests/test_bdd_docker_integration.py",
        },
        workspace_dir=tmp_path,
    )

    plan = plan_mock_docker_bdd(config)

    assert plan.prepare_command[:4] == (
        "docker",
        "compose",
        "--project-name",
        "demo-itest",
    )
    assert plan.test_command == ("pytest", "-q", "tests/test_bdd_docker_integration.py")
    assert plan.teardown_command[-2:] == ("down", "--volumes")
    assert "image: python:3.12-slim" in plan.compose_yaml
    assert "command: ['pytest -q tests/test_bdd_docker_integration.py']" in plan.compose_yaml
    assert f"- {tmp_path.resolve()}:/workspace:ro" in plan.compose_yaml


def test_load_docker_integration_config_requires_tether_image_for_real_mode(
    tmp_path: Path,
) -> None:
    try:
        load_docker_integration_config(
            env={"TAD_DOCKER_MOCK": "false"},
            workspace_dir=tmp_path,
        )
    except ValueError as exc:
        assert "TAD_DOCKER_TETHER_IMAGE" in str(exc)
    else:
        raise AssertionError("Expected missing live tether image to fail")


def test_plan_real_docker_bdd_is_opt_in_and_isolated(tmp_path: Path) -> None:
    config = load_docker_integration_config(
        env={
            "TAD_DOCKER_MOCK": "false",
            "TAD_DOCKER_PROJECT": "demo-live-itest",
            "TAD_DOCKER_TETHER_IMAGE": "ghcr.io/example/tether:test",
            "TAD_DOCKER_PYTEST_TARGET": "tests/test_docker_integration.py",
            "TAD_DOCKER_TETHER_PORT": "9988",
        },
        workspace_dir=tmp_path,
    )

    plan = plan_real_docker_bdd(config)

    assert plan.mock_mode is False
    assert plan.test_command[:4] == ("docker", "compose", "--project-name", "demo-live-itest")
    assert "--exit-code-from" in plan.test_command
    assert "image: ghcr.io/example/tether:test" in plan.compose_yaml
    assert "TAD_TETHER_HOST: tether" in plan.compose_yaml
    assert 'TAD_TETHER_PORT: "9988"' in plan.compose_yaml
    assert f"- {tmp_path.resolve()}:/workspace:rw" in plan.compose_yaml


def test_plan_real_docker_bdd_can_use_fake_tether_fixture(tmp_path: Path) -> None:
    config = load_docker_integration_config(
        env={
            "TAD_DOCKER_MOCK": "false",
            "TAD_DOCKER_FAKE_TETHER": "true",
            "TAD_DOCKER_FAKE_SESSIONS": "codexA,openB",
            "TAD_DOCKER_INSTALL_DEB": "true",
            "TAD_DOCKER_DEB_PATH": _package_deb_path(),
            "TAD_DOCKER_PYTEST_TARGET": "tests/test_kali_package_integration.py",
        },
        workspace_dir=tmp_path,
    )

    plan = plan_real_docker_bdd(config)

    assert "image: tether:latest" not in plan.compose_yaml
    assert "depends_on:" not in plan.compose_yaml
    assert 'TAD_START_TETHER: "false"' in plan.compose_yaml
    assert "command: ['apt-get update &&" in plan.compose_yaml
    assert "TAD_TETHER_BIN: /workspace/tests/fixtures/fake_tether_cli.py" in plan.compose_yaml
    assert "TAD_FAKE_TETHER_SESSIONS: codexA,openB" in plan.compose_yaml
    assert "TAD_FAKE_TETHER_ATTACH_LOG: /tmp/tad-attach-log.jsonl" in plan.compose_yaml
    assert "TAD_FAKE_TETHER_SYNC_LOG: /tmp/tad-sync-log.jsonl" in plan.compose_yaml


def test_direct_real_docker_bdd_command_supports_fake_tether_without_compose(
    tmp_path: Path,
) -> None:
    config = load_docker_integration_config(
        env={
            "TAD_DOCKER_MOCK": "false",
            "TAD_DOCKER_FAKE_TETHER": "true",
            "TAD_DOCKER_FAKE_SESSIONS": "codexA,openB",
            "TAD_DOCKER_INSTALL_DEB": "true",
            "TAD_DOCKER_DEB_PATH": _package_deb_path(),
            "TAD_DOCKER_PYTEST_TARGET": "tests/test_kali_package_integration.py",
        },
        workspace_dir=tmp_path,
    )

    command = direct_real_docker_bdd_command(config)

    assert command[:6] == (
        "docker",
        "run",
        "--rm",
        "--name",
        "tether-autolaunchd-itest-bdd",
        "--workdir",
    )
    assert f"{tmp_path.resolve()}:/workspace:rw" in command
    assert "TAD_TETHER_BIN=/workspace/tests/fixtures/fake_tether_cli.py" in command
    assert "TAD_FAKE_TETHER_SESSIONS=codexA,openB" in command
    assert "python3-pytest" in command[-1]
    assert "pytest -q tests/test_kali_package_integration.py" in command[-1]


def test_plan_docker_bdd_dispatches_by_mode(tmp_path: Path) -> None:
    mock_config = load_docker_integration_config(env={}, workspace_dir=tmp_path)
    live_config = load_docker_integration_config(
        env={
            "TAD_DOCKER_MOCK": "false",
            "TAD_DOCKER_TETHER_IMAGE": "ghcr.io/example/tether:test",
        },
        workspace_dir=tmp_path,
    )

    assert plan_docker_bdd(mock_config).mock_mode is True
    assert plan_docker_bdd(live_config).mock_mode is False


def test_bdd_demo_tape_references_bdd_and_live_prepare_flow() -> None:
    root = Path(__file__).resolve().parents[1]
    tape = (root / "tapes" / "bdd-demo.tape").read_text(encoding="utf-8")
    assert "Output docs/tether-autolaunchd-bdd-demo.gif" in tape
    assert "make bdd" in tape
    assert "scripts/run_docker_bdd.py --prepare-only" in tape
    assert "Wait+Screen /prepared compose file: docker-compose.real.yml/" in tape


def test_readme_references_tracked_bdd_demo_gif() -> None:
    root = Path(__file__).resolve().parents[1]
    readme = (root / "README.md").read_text(encoding="utf-8")
    assert "docs/tether-autolaunchd-bdd-demo.gif" in readme
    assert "make bdd-vhs" in readme
    assert "installing `ttyd` plus `vhs` on the runner" in readme
    assert "`vhs` and `ttyd`" in readme


def test_workflow_installs_vhs_and_ttyd_and_uses_repo_target_for_demo_render() -> None:
    workflow = (Path(__file__).resolve().parents[1] / ".github" / "workflows" / "ci.yml").read_text(
        encoding="utf-8"
    )
    assert "name: Install ttyd and VHS" in workflow
    assert "apt-get install -y ttyd" in workflow
    assert "vhs_0.11.0_amd64.deb" in workflow
    assert "run: make bdd-vhs" in workflow


def test_bdd_vhs_target_falls_back_when_ttyd_is_missing() -> None:
    makefile = (Path(__file__).resolve().parents[1] / "Makefile").read_text(encoding="utf-8")
    assert "command -v vhs >/dev/null 2>&1 && command -v ttyd >/dev/null 2>&1" in makefile
    assert (
        'docker run --rm -v "$(CURDIR):/vhs" ghcr.io/charmbracelet/vhs tapes/bdd-demo.tape'
    ) in makefile
