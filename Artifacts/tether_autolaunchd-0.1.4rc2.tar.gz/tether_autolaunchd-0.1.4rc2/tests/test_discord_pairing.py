from __future__ import annotations

import hashlib
import json
from pathlib import Path

from tether_autolaunchd.discord_pairing import (
    automate_pairing_from_local_log,
    extract_latest_pairing_code,
)


def test_extract_latest_pairing_code_reads_ansi_log_lines() -> None:
    log_text = (
        "\x1b[33m2026-04-01\x1b[0m Discord pairing enabled. DM the bot: !pair <code> "
        "code=tether-setup-20260401\n"
    )

    assert extract_latest_pairing_code(log_text) == "tether-setup-20260401"


def test_automate_pairing_from_local_log_sends_pair_and_resource_reply(tmp_path: Path) -> None:
    log_path = tmp_path / "tether-autolaunchd.log"
    state_path = tmp_path / "discord-pairing-automation.json"
    pairing_code = "tether-setup-20260401"
    log_path.write_text(
        (f"2026-04-01 Discord pairing enabled. DM the bot: !pair <code> code={pairing_code}\n"),
        encoding="utf-8",
    )
    calls: list[tuple[str, str, str, dict[str, object] | None]] = []

    def fake_request(method: str, path: str, authorization: str, payload: dict[str, object] | None):
        calls.append((method, path, authorization, payload))
        if (method, path, authorization) == ("GET", "/users/@me", "Bot bot-token"):
            return {"id": "bot-123"}
        if (method, path, authorization) == ("POST", "/users/@me/channels", "user-token"):
            assert payload == {"recipient_id": "bot-123"}
            return {"id": "dm-456"}
        if (method, path, authorization) == ("POST", "/channels/dm-456/messages", "user-token"):
            if payload == {"content": f"!pair {pairing_code}"}:
                return {"id": "msg-pair"}
            if payload == {"content": "yes"}:
                return {"id": "msg-yes"}
        if (method, path, authorization) == (
            "GET",
            "/channels/dm-456/messages?limit=10",
            "user-token",
        ):
            return [
                {
                    "id": "prompt-789",
                    "content": (
                        "Are resources of system available for maintaining this session now?"
                    ),
                    "author": {"id": "bot-123"},
                }
            ]
        raise AssertionError(f"Unexpected request: {(method, path, authorization, payload)}")

    result = automate_pairing_from_local_log(
        bot_token="bot-token",
        automation_token="user-token",
        pairing_log_path=log_path,
        state_path=state_path,
        now_timestamp=lambda: "2026-04-01T16:30:00Z",
        request_json=fake_request,
    )

    assert result.pairing_code_found is True
    assert result.pair_command_sent is True
    assert result.resource_reply_sent is True
    assert result.dm_channel_id == "dm-456"

    payload = json.loads(state_path.read_text(encoding="utf-8"))
    expected_hash = hashlib.sha256(pairing_code.encode("utf-8")).hexdigest()
    assert payload["last_pair_code_sha256"] == expected_hash
    assert "tether-setup-20260401" not in state_path.read_text(encoding="utf-8")


def test_automate_pairing_from_local_log_skips_repeat_pair_command_for_same_code(
    tmp_path: Path,
) -> None:
    log_path = tmp_path / "tether-autolaunchd.log"
    state_path = tmp_path / "discord-pairing-automation.json"
    pairing_code = "tether-setup-20260401"
    log_path.write_text(
        (f"2026-04-01 Discord pairing enabled. DM the bot: !pair <code> code={pairing_code}\n"),
        encoding="utf-8",
    )
    state_path.write_text(
        json.dumps(
            {
                "bot_user_id": "bot-123",
                "dm_channel_id": "dm-456",
                "last_pair_code_sha256": hashlib.sha256(pairing_code.encode("utf-8")).hexdigest(),
            }
        ),
        encoding="utf-8",
    )
    seen_pair_message = {"called": False}

    def fake_request(method: str, path: str, authorization: str, payload: dict[str, object] | None):
        if (method, path, authorization) == (
            "GET",
            "/channels/dm-456/messages?limit=10",
            "user-token",
        ):
            return []
        if (method, path, authorization) == ("POST", "/channels/dm-456/messages", "user-token"):
            seen_pair_message["called"] = True
            return {"id": "should-not-send"}
        raise AssertionError(f"Unexpected request: {(method, path, authorization, payload)}")

    result = automate_pairing_from_local_log(
        bot_token="bot-token",
        automation_token="user-token",
        pairing_log_path=log_path,
        state_path=state_path,
        now_timestamp=lambda: "2026-04-01T16:35:00Z",
        request_json=fake_request,
    )

    assert result.pair_command_sent is False
    assert seen_pair_message["called"] is False
