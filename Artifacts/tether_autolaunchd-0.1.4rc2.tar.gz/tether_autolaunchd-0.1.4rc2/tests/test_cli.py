from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

from tether_autolaunchd import cli
from tether_autolaunchd.runtime import RunSummary


def test_main_once_emits_json(monkeypatch, capsys) -> None:
    monkeypatch.setattr("tether_autolaunchd.cli.load_config", lambda: object())
    monkeypatch.setattr(
        "tether_autolaunchd.cli.run_once",
        lambda _config: RunSummary(True, ("abc",), ("abc",), synced_ids=("def",)),
    )
    result = cli.main(["once"])
    payload = json.loads(capsys.readouterr().out)
    assert result == 0
    assert payload["started_tether"] is True
    assert payload["attached_ids"] == ["abc"]
    assert payload["synced_ids"] == ["def"]


def test_main_print_user_unit(monkeypatch, capsys) -> None:
    monkeypatch.setattr("tether_autolaunchd.cli.load_config", lambda: object())
    monkeypatch.setattr("tether_autolaunchd.cli.render_user_service", lambda _config: "[Unit]\n")
    assert cli.main(["print-user-unit"]) == 0
    assert capsys.readouterr().out == "[Unit]\n"


def test_main_print_status_json(monkeypatch, capsys) -> None:
    monkeypatch.setattr("tether_autolaunchd.cli.load_config", lambda: object())
    monkeypatch.setattr(
        "tether_autolaunchd.cli.load_status_snapshot",
        lambda _config: {
            "generated_at": "2026-04-01T00:00:00Z",
            "last_pass": {"attached_count": 1},
        },
    )
    assert cli.main(["print-status-json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["generated_at"] == "2026-04-01T00:00:00Z"
    assert payload["last_pass"]["attached_count"] == 1


def test_main_daemon_reloads_config_each_iteration(monkeypatch, capsys) -> None:
    loads: list[str] = []
    configs = iter(
        [
            SimpleNamespace(name="cfg-1", poll_seconds=0),
            SimpleNamespace(name="cfg-2", poll_seconds=0),
        ]
    )

    def fake_load_config():
        config = next(configs)
        loads.append(config.name)
        return config

    seen: list[str] = []

    def fake_run_once(config):
        seen.append(config.name)
        return RunSummary(False, ("abc",), (), synced_ids=("abc",))

    monkeypatch.setattr("tether_autolaunchd.cli.load_config", fake_load_config)
    monkeypatch.setattr("tether_autolaunchd.cli.run_once", fake_run_once)

    assert cli.main(["daemon", "--iterations", "2"]) == 0
    assert loads == ["cfg-1", "cfg-2"]
    assert seen == ["cfg-1", "cfg-2"]
    lines = capsys.readouterr().out.splitlines()
    assert len(lines) == 2
    first = json.loads(lines[0])
    assert first["synced_count"] == 1


def test_module_entrypoint_invokes_main() -> None:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
    result = subprocess.run(
        [sys.executable, "-m", "tether_autolaunchd.cli", "print-env"],
        check=True,
        capture_output=True,
        text=True,
        env=env,
    )
    assert "TAD_TETHER_BIN=tether" in result.stdout
