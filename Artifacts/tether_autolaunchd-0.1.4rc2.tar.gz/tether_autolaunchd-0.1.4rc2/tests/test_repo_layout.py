from __future__ import annotations

from pathlib import Path


def test_env_file_is_ignored_and_sample_is_masked() -> None:
    root = Path(__file__).resolve().parents[1]
    gitignore = (root / ".gitignore").read_text(encoding="utf-8")
    sample = (root / ".env.sample").read_text(encoding="utf-8")

    assert ".env" in gitignore
    assert "masked-discord-token" in sample
    assert "your-real" not in sample


def test_release_workflow_publishes_deb_and_python_artifacts() -> None:
    root = Path(__file__).resolve().parents[1]
    workflow = (root / ".github" / "workflows" / "release.yml").read_text(encoding="utf-8")

    assert "name: Release" in workflow
    assert "make build-python-dist" in workflow
    assert "make build-deb" in workflow
    assert "gh release" in workflow
    assert "--prerelease" in workflow
