from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def _root() -> Path:
    return Path(__file__).resolve().parents[1]


def test_docs_generator_writes_markdown_and_site(tmp_path: Path) -> None:
    markdown_dir = tmp_path / "feature-tour"
    site_dir = tmp_path / "site"
    subprocess.run(
        [
            sys.executable,
            "scripts/generate_docs_site.py",
            "--markdown-dir",
            str(markdown_dir),
            "--site-dir",
            str(site_dir),
        ],
        cwd=_root(),
        check=True,
    )

    index_md = (markdown_dir / "README.md").read_text(encoding="utf-8")
    feature_md = (markdown_dir / "discord-machine-channels.md").read_text(encoding="utf-8")
    index_html = (site_dir / "index.html").read_text(encoding="utf-8")
    feature_html = (site_dir / "features" / "discord-machine-channels" / "index.html").read_text(
        encoding="utf-8"
    )

    assert "## Chapters" in index_md
    assert "```mermaid" in feature_md
    assert "```text" in feature_md
    assert "feature-grid" in index_html
    assert "Open Markdown source" in feature_html
    assert 'class="ascii"' in feature_html


def test_tracked_markdown_docs_match_generator_output(tmp_path: Path) -> None:
    generated_dir = tmp_path / "feature-tour"
    subprocess.run(
        [
            sys.executable,
            "scripts/generate_docs_site.py",
            "--markdown-dir",
            str(generated_dir),
            "--site-dir",
            str(tmp_path / "site"),
        ],
        cwd=_root(),
        check=True,
    )

    tracked_dir = _root() / "docs" / "feature-tour"
    generated_files = sorted(
        path.relative_to(generated_dir) for path in generated_dir.rglob("*.md")
    )
    tracked_files = sorted(path.relative_to(tracked_dir) for path in tracked_dir.rglob("*.md"))

    assert tracked_files == generated_files
    for relative in generated_files:
        assert (tracked_dir / relative).read_text(encoding="utf-8") == (
            generated_dir / relative
        ).read_text(encoding="utf-8")


def test_pages_workflow_builds_generated_site() -> None:
    workflow = (_root() / ".github" / "workflows" / "pages.yml").read_text(encoding="utf-8")

    assert "actions/upload-pages-artifact" in workflow
    assert "actions/deploy-pages" in workflow
    assert "scripts/generate_docs_site.py" in workflow


def test_makefile_wires_docs_generation_into_ci() -> None:
    makefile = (_root() / "Makefile").read_text(encoding="utf-8")

    assert "docs-site:" in makefile
    assert "check-docs-site: docs-site" in makefile
    assert "$(MAKE) check-docs-site" in makefile
    assert "verify: lint check-docs-site test" in makefile


def test_readme_links_to_live_feature_tour() -> None:
    readme = (_root() / "README.md").read_text(encoding="utf-8")

    assert "docs/tether-autolaunchd-docs-site.png" in readme
    assert "realagiorganization.github.io/tether-autolaunchd" in readme
