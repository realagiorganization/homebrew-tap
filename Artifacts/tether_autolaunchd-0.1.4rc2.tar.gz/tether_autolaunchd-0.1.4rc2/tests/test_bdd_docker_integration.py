from __future__ import annotations

from pathlib import Path

from pytest_bdd import given, scenario, then, when

from tether_autolaunchd.docker_integration import (
    DockerIntegrationPlan,
    load_docker_integration_config,
    plan_mock_docker_bdd,
    plan_real_docker_bdd,
)


@scenario(
    "../features/docker_integration.feature",
    "Build an isolated mocked Docker BDD plan",
)
def test_build_mocked_docker_bdd_plan() -> None:
    """BDD coverage for the mocked Docker integration scaffold."""


@scenario(
    "../features/docker_integration.feature",
    "Build an opt-in live Docker BDD plan",
)
def test_build_live_docker_bdd_plan() -> None:
    """BDD coverage for the opt-in live Docker integration plan."""


@given("a mocked Docker integration configuration", target_fixture="docker_context")
def given_docker_config(tmp_path: Path) -> dict[str, object]:
    config = load_docker_integration_config(
        env={
            "TAD_DOCKER_PROJECT": "tad-mock-itest",
            "TAD_DOCKER_BASE_IMAGE": "python:3.11-slim",
            "TAD_DOCKER_MOCK": "true",
            "TAD_DOCKER_PYTEST_TARGET": "tests/test_bdd_docker_integration.py",
        },
        workspace_dir=tmp_path,
    )
    return {"config": config}


@when("the mocked Docker integration plan is built")
def when_plan_is_built(docker_context: dict[str, object]) -> None:
    config = docker_context["config"]
    docker_context["plan"] = plan_mock_docker_bdd(config)


@then("the plan uses an isolated docker compose project")
def then_plan_uses_isolated_project(docker_context: dict[str, object]) -> None:
    plan: DockerIntegrationPlan = docker_context["plan"]  # type: ignore[assignment]
    assert "--project-name" in plan.prepare_command
    assert "tad-mock-itest" in plan.prepare_command
    assert "container_name: tad-mock-itest-bdd" in plan.compose_yaml


@then("the plan targets the Docker BDD pytest suite")
def then_plan_targets_pytest_suite(docker_context: dict[str, object]) -> None:
    plan: DockerIntegrationPlan = docker_context["plan"]  # type: ignore[assignment]
    assert plan.test_command == ("pytest", "-q", "tests/test_bdd_docker_integration.py")
    assert "pytest -q tests/test_bdd_docker_integration.py" in plan.compose_yaml


@then("the plan can be exercised without a live Docker daemon")
def then_plan_is_mock_safe(docker_context: dict[str, object]) -> None:
    plan: DockerIntegrationPlan = docker_context["plan"]  # type: ignore[assignment]
    assert plan.mock_mode is True
    assert plan.prepare_command[-1] == "config"


@given("an opt-in live Docker integration configuration", target_fixture="live_docker_context")
def given_live_docker_config(tmp_path: Path) -> dict[str, object]:
    config = load_docker_integration_config(
        env={
            "TAD_DOCKER_PROJECT": "tad-live-itest",
            "TAD_DOCKER_BASE_IMAGE": "python:3.11-slim",
            "TAD_DOCKER_MOCK": "false",
            "TAD_DOCKER_TETHER_IMAGE": "ghcr.io/example/tether:test",
            "TAD_DOCKER_PYTEST_TARGET": "tests/test_docker_integration.py",
        },
        workspace_dir=tmp_path,
    )
    return {"config": config}


@when("the live Docker integration plan is built")
def when_live_plan_is_built(live_docker_context: dict[str, object]) -> None:
    config = live_docker_context["config"]
    live_docker_context["plan"] = plan_real_docker_bdd(config)


@then("the plan includes a dedicated tether service")
def then_live_plan_includes_tether(live_docker_context: dict[str, object]) -> None:
    plan: DockerIntegrationPlan = live_docker_context["plan"]  # type: ignore[assignment]
    assert "services:" in plan.compose_yaml
    assert "image: ghcr.io/example/tether:test" in plan.compose_yaml
    assert "--exit-code-from" in plan.test_command


@then("the live plan is isolated from the mocked CI default")
def then_live_plan_stays_opt_in(live_docker_context: dict[str, object]) -> None:
    plan: DockerIntegrationPlan = live_docker_context["plan"]  # type: ignore[assignment]
    assert plan.mock_mode is False
    assert 'TAD_DOCKER_MOCK: "false"' in plan.compose_yaml
    assert plan.prepare_command[-1] == "config"
