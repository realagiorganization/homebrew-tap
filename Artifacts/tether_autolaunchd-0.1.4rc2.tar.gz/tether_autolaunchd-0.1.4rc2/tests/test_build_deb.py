from __future__ import annotations

from pathlib import Path


def test_packaging_assets_exist() -> None:
    root = Path(__file__).resolve().parents[1]
    assert (root / "scripts" / "build_deb.py").exists()
    assert (
        root
        / "packaging"
        / "debian"
        / "usr"
        / "lib"
        / "systemd"
        / "user"
        / "tether-autolaunchd.service"
    ).exists()
    build_script = (root / "scripts" / "build_deb.py").read_text(encoding="utf-8")
    assert "python3-platformdirs" in build_script
    assert "tether-autolaunchd.service" in build_script
    assert "/opt/tether-autolaunchd/src${PYTHONPATH:+:$PYTHONPATH}" in build_script
    assert "exec /usr/bin/python3 -m tether_autolaunchd.cli" in build_script
    assert 'exec_start="/usr/bin/tether-autolaunchd daemon"' in build_script
    assert "package_maintainer(ROOT)" in build_script
    assert "debian_package_version(__version__)" in build_script
