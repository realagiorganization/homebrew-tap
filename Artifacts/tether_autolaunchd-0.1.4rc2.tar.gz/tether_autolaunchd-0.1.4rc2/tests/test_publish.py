from __future__ import annotations

import gzip
import subprocess
from pathlib import Path

from tether_autolaunchd.publish import (
    APT_REPO_TILDE_MARKER,
    DebianArchiveMetadata,
    HomebrewResource,
    apt_repo_channel,
    apt_repo_deb_filename,
    deb_archive_metadata,
    debian_package_version,
    formula_class_name,
    is_malformed_debian_prerelease,
    is_prerelease_version,
    normalize_repo_deb_filenames,
    package_maintainer,
    render_homebrew_formula,
    runtime_dependency_names,
    write_flat_apt_overlay,
)


def test_formula_class_name_normalizes_package_name() -> None:
    assert formula_class_name("tether-autolaunchd") == "TetherAutolaunchd"


def test_runtime_dependency_names_reads_top_level_dependencies() -> None:
    root = Path(__file__).resolve().parents[1]
    assert runtime_dependency_names(root) == ("platformdirs",)


def test_package_metadata_helpers_read_maintainer_and_debian_version() -> None:
    root = Path(__file__).resolve().parents[1]
    assert package_maintainer(root) == "Lars de Ridder <lars@xithing.io>"
    assert debian_package_version("0.1.3rc2") == "0.1.3~rc2"
    assert debian_package_version("0.1.3") == "0.1.3"


def test_apt_repo_deb_filename_rewrites_tilde_for_url_safety() -> None:
    assert (
        apt_repo_deb_filename("tether-autolaunchd_0.1.4~rc1_all.deb")
        == f"tether-autolaunchd_0.1.4{APT_REPO_TILDE_MARKER}rc1_all.deb"
    )
    assert apt_repo_deb_filename("tether-autolaunchd_0.1.2_all.deb") == (
        "tether-autolaunchd_0.1.2_all.deb"
    )


def test_is_malformed_debian_prerelease_rejects_non_tilde_versions() -> None:
    assert is_malformed_debian_prerelease("0.1.3rc2") is True
    assert is_malformed_debian_prerelease("0.1.3~rc2") is False
    assert is_malformed_debian_prerelease("0.1.3") is False


def test_prerelease_helpers_route_release_candidates_to_rc_channel() -> None:
    assert is_prerelease_version("0.1.4rc1") is True
    assert is_prerelease_version("0.1.4~rc1") is True
    assert is_prerelease_version("0.1.4") is False
    assert apt_repo_channel("0.1.4rc1") == "rc"
    assert apt_repo_channel("0.1.4~rc1") == "rc"
    assert apt_repo_channel("0.1.4") == "stable"


def test_deb_archive_metadata_parses_named_dpkg_fields(monkeypatch, tmp_path: Path) -> None:
    deb_path = tmp_path / "package.deb"
    deb_path.write_bytes(b"deb")

    def fake_run(*args, **kwargs) -> subprocess.CompletedProcess[str]:
        command = args[0]
        assert command[:2] == ["dpkg-deb", "-f"]
        return subprocess.CompletedProcess(
            command,
            0,
            stdout=("Package: tether-autolaunchd\nVersion: 0.1.3rc2\nArchitecture: all\n"),
            stderr="",
        )

    monkeypatch.setattr("tether_autolaunchd.publish.subprocess.run", fake_run)

    metadata = deb_archive_metadata(deb_path)

    assert metadata == DebianArchiveMetadata(
        package="tether-autolaunchd",
        version="0.1.3rc2",
        architecture="all",
    )


def test_render_homebrew_formula_includes_release_asset_and_resources() -> None:
    formula = render_homebrew_formula(
        name="tether-autolaunchd",
        description="Local Tether launcher",
        homepage="https://github.com/example/tether-autolaunchd",
        version="0.1.0",
        sdist_url="https://github.com/example/tether-autolaunchd/releases/download/v0.1.0/pkg.tar.gz",
        sdist_sha256="abc123",
        resources=(
            HomebrewResource(
                name="platformdirs",
                url="https://files.pythonhosted.org/packages/demo/platformdirs.tar.gz",
                sha256="def456",
            ),
        ),
    )

    assert "class TetherAutolaunchd < Formula" in formula
    assert (
        'url "https://github.com/example/tether-autolaunchd/releases/download/v0.1.0/pkg.tar.gz"'
        in formula
    )
    assert 'depends_on "python@3.12"' in formula
    assert 'resource "platformdirs" do' in formula
    assert 'shell_output("#{bin}/tether-autolaunchd print-env")' in formula


def test_write_flat_apt_overlay_writes_packages_indexes(
    monkeypatch,
    tmp_path: Path,
) -> None:
    deb_path = tmp_path / "tether-autolaunchd_0.1.0_all.deb"
    deb_path.write_bytes(b"deb")
    captured: list[tuple[object, object]] = []

    def fake_run(*args, **kwargs) -> subprocess.CompletedProcess[str]:
        command = args[0]
        cwd = kwargs.get("cwd")
        captured.append((command, cwd))
        if command[:2] == ["dpkg-deb", "-f"]:
            raise ValueError("not a deb archive in this unit test")
        if command[:2] == ["dpkg-scanpackages", "--multiversion"]:
            return subprocess.CompletedProcess(
                command,
                0,
                stdout=(
                    "Package: tether-autolaunchd\nFilename: ./tether-autolaunchd_0.1.0_all.deb\n"
                ),
                stderr="",
            )
        return subprocess.CompletedProcess(
            command,
            0,
            stdout="Origin: realagiorganization\nSuite: stable\n",
            stderr="",
        )

    monkeypatch.setattr("tether_autolaunchd.publish.subprocess.run", fake_run)

    target_deb, packages_path, packages_gz_path, release_path, inrelease_path, release_gpg_path = (
        write_flat_apt_overlay(
            tmp_path / "overlay",
            deb_path,
        )
    )

    assert target_deb.name == "tether-autolaunchd_0.1.0_all.deb"
    assert packages_path.read_text(encoding="utf-8").startswith("Package: tether-autolaunchd")
    with gzip.open(packages_gz_path, "rt", encoding="utf-8") as handle:
        assert "Filename: ./tether-autolaunchd_0.1.0_all.deb" in handle.read()
    assert release_path.read_text(encoding="utf-8").startswith("Origin: realagiorganization")
    assert inrelease_path is None
    assert release_gpg_path is None
    assert captured == [
        (
            [
                "dpkg-deb",
                "-f",
                str(deb_path),
                "Package",
                "Version",
                "Architecture",
            ],
            None,
        ),
        (["dpkg-scanpackages", "--multiversion", "."], target_deb.parent),
        (
            [
                "apt-ftparchive",
                "-o",
                "APT::FTPArchive::Release::Origin=realagiorganization",
                "-o",
                "APT::FTPArchive::Release::Label=tether-autolaunchd",
                "-o",
                "APT::FTPArchive::Release::Suite=stable",
                "-o",
                "APT::FTPArchive::Release::Codename=stable",
                "-o",
                "APT::FTPArchive::Release::Architectures=all",
                "-o",
                "APT::FTPArchive::Release::Components=main",
                "-o",
                (
                    "APT::FTPArchive::Release::Description="
                    "Signed flat APT repository for tether-autolaunchd."
                ),
                "release",
                ".",
            ],
            target_deb.parent,
        ),
    ]


def test_normalize_repo_deb_filenames_renames_existing_prerelease_archives(tmp_path: Path) -> None:
    repo_dir = tmp_path / "overlay"
    repo_dir.mkdir()
    legacy = repo_dir / "tether-autolaunchd_0.1.3~rc2_all.deb"
    legacy.write_bytes(b"legacy")

    normalize_repo_deb_filenames(repo_dir)

    assert not legacy.exists()
    assert (repo_dir / f"tether-autolaunchd_0.1.3{APT_REPO_TILDE_MARKER}rc2_all.deb").exists()


def test_normalize_repo_deb_filenames_prunes_malformed_prerelease_archives(
    monkeypatch,
    tmp_path: Path,
) -> None:
    repo_dir = tmp_path / "overlay"
    repo_dir.mkdir()
    malformed = repo_dir / "tether-autolaunchd_0.1.3rc2_all.deb"
    malformed.write_bytes(b"legacy")

    monkeypatch.setattr(
        "tether_autolaunchd.publish.deb_archive_metadata",
        lambda path: DebianArchiveMetadata(
            package="tether-autolaunchd",
            version="0.1.3rc2",
            architecture="all",
        ),
    )

    normalize_repo_deb_filenames(repo_dir)

    assert not malformed.exists()


def test_normalize_repo_deb_filenames_uses_archive_metadata_for_canonical_names(
    monkeypatch,
    tmp_path: Path,
) -> None:
    repo_dir = tmp_path / "overlay"
    repo_dir.mkdir()
    archive = repo_dir / "downloaded.deb"
    archive.write_bytes(b"deb")

    monkeypatch.setattr(
        "tether_autolaunchd.publish.deb_archive_metadata",
        lambda path: DebianArchiveMetadata(
            package="tether-autolaunchd",
            version="0.1.4~rc1",
            architecture="all",
        ),
    )

    normalize_repo_deb_filenames(repo_dir)

    assert not archive.exists()
    assert (repo_dir / f"tether-autolaunchd_0.1.4{APT_REPO_TILDE_MARKER}rc1_all.deb").exists()


def test_write_flat_apt_overlay_uses_url_safe_prerelease_filename(
    monkeypatch,
    tmp_path: Path,
) -> None:
    repo_dir = tmp_path / "overlay"
    repo_dir.mkdir()
    legacy = repo_dir / "tether-autolaunchd_0.1.3~rc2_all.deb"
    legacy.write_bytes(b"legacy")

    deb_path = tmp_path / "tether-autolaunchd_0.1.4~rc1_all.deb"
    deb_path.write_bytes(b"deb")

    def fake_run(*args, **kwargs) -> subprocess.CompletedProcess[str]:
        command = args[0]
        if command[:2] == ["dpkg-scanpackages", "--multiversion"]:
            return subprocess.CompletedProcess(
                command,
                0,
                stdout=(
                    "Package: tether-autolaunchd\n"
                    f"Filename: ./tether-autolaunchd_0.1.4{APT_REPO_TILDE_MARKER}rc1_all.deb\n"
                ),
                stderr="",
            )
        return subprocess.CompletedProcess(
            command,
            0,
            stdout="Origin: realagiorganization\nSuite: stable\n",
            stderr="",
        )

    monkeypatch.setattr("tether_autolaunchd.publish.subprocess.run", fake_run)

    target_deb, packages_path, *_ = write_flat_apt_overlay(repo_dir, deb_path)

    assert target_deb.name == f"tether-autolaunchd_0.1.4{APT_REPO_TILDE_MARKER}rc1_all.deb"
    assert not (repo_dir / "tether-autolaunchd_0.1.3~rc2_all.deb").exists()
    assert (repo_dir / f"tether-autolaunchd_0.1.3{APT_REPO_TILDE_MARKER}rc2_all.deb").exists()
    assert (
        packages_path.read_text(encoding="utf-8").splitlines()[1]
        == f"Filename: ./tether-autolaunchd_0.1.4{APT_REPO_TILDE_MARKER}rc1_all.deb"
    )


def test_write_flat_apt_overlay_rebuilds_malformed_prerelease_deb(
    monkeypatch,
    tmp_path: Path,
) -> None:
    repo_dir = tmp_path / "overlay"
    repo_dir.mkdir()
    deb_path = tmp_path / "tether-autolaunchd_0.1.3rc2_all.deb"
    deb_path.write_bytes(b"deb")

    def fake_run(*args, **kwargs) -> subprocess.CompletedProcess[str]:
        command = args[0]
        if command[:2] == ["dpkg-deb", "-f"]:
            return subprocess.CompletedProcess(
                command,
                0,
                stdout=("Package: tether-autolaunchd\nVersion: 0.1.3rc2\nArchitecture: all\n"),
                stderr="",
            )
        if command[:2] == ["dpkg-deb", "-R"]:
            unpacked_dir = Path(command[3])
            control_path = unpacked_dir / "DEBIAN" / "control"
            control_path.parent.mkdir(parents=True, exist_ok=True)
            control_path.write_text(
                "Package: tether-autolaunchd\nVersion: 0.1.3rc2\nArchitecture: all\n",
                encoding="utf-8",
            )
            return subprocess.CompletedProcess(command, 0, stdout="", stderr="")
        if command[:3] == ["dpkg-deb", "--root-owner-group", "--build"]:
            rebuilt_path = Path(command[4])
            rebuilt_path.write_bytes(b"rebuilt")
            return subprocess.CompletedProcess(command, 0, stdout="", stderr="")
        if command[:2] == ["dpkg-scanpackages", "--multiversion"]:
            return subprocess.CompletedProcess(
                command,
                0,
                stdout=(
                    "Package: tether-autolaunchd\n"
                    f"Filename: ./tether-autolaunchd_0.1.3{APT_REPO_TILDE_MARKER}rc2_all.deb\n"
                ),
                stderr="",
            )
        return subprocess.CompletedProcess(
            command,
            0,
            stdout="Origin: realagiorganization\nSuite: rc\n",
            stderr="",
        )

    monkeypatch.setattr("tether_autolaunchd.publish.subprocess.run", fake_run)

    target_deb, packages_path, *_ = write_flat_apt_overlay(repo_dir, deb_path)

    assert target_deb.name == f"tether-autolaunchd_0.1.3{APT_REPO_TILDE_MARKER}rc2_all.deb"
    assert target_deb.read_bytes() == b"rebuilt"
    assert (
        packages_path.read_text(encoding="utf-8").splitlines()[1]
        == f"Filename: ./tether-autolaunchd_0.1.3{APT_REPO_TILDE_MARKER}rc2_all.deb"
    )


def test_release_workflow_publishes_tap_and_apt_overlay() -> None:
    workflow = (
        Path(__file__).resolve().parents[1] / ".github" / "workflows" / "release.yml"
    ).read_text(encoding="utf-8")
    assert "PUBLISH_REPO_TOKEN" in workflow
    assert "APT_REPO_GPG_PRIVATE_KEY" in workflow
    assert "APT_REPO_GPG_PASSPHRASE" in workflow
    assert "realagiorganization/homebrew-tap" in workflow
    assert "realagiorganization/tether-autolaunchd-apt" in workflow
    assert "scripts/build_homebrew_formula.py" in workflow
    assert "scripts/build_flat_apt_overlay.py" in workflow
    assert "DEBIAN_VERSION" in workflow
    assert "APT_CHANNEL" in workflow
    assert "/stable" in workflow
    assert "/rc" in workflow
    assert "tether-autolaunchd-archive-keyring.gpg" in workflow
    assert "-tilde-" in workflow


def test_docs_mention_homebrew_and_apt_overlay() -> None:
    root = Path(__file__).resolve().parents[1]
    readme = (root / "README.md").read_text(encoding="utf-8")
    install = (root / "install.md").read_text(encoding="utf-8")
    assert "brew tap realagiorganization/tap" in readme
    assert "tether-autolaunchd-archive-keyring.gpg" in readme
    assert "signed-by=${KEYRING}" in readme
    assert "${REPO_ROOT}/stable" in readme
    assert "${REPO_ROOT}/rc" in readme
    assert "brew tap realagiorganization/tap" in install
    assert "tether-autolaunchd-archive-keyring.gpg" in install
    assert "signed-by=${KEYRING}" in install
    assert "${REPO_ROOT}/stable" in install
    assert "${REPO_ROOT}/rc" in install
