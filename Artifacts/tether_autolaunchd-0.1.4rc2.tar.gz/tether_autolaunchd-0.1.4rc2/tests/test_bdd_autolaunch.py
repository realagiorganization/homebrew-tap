from __future__ import annotations

import subprocess
from pathlib import Path

from pytest_bdd import given, scenario, then, when

from tether_autolaunchd.config import AppConfig
from tether_autolaunchd.runtime import RunSummary, run_once


@scenario(
    "../features/autolaunch.feature",
    "Attach newly discovered external sessions and remember them",
)
def test_attach_new_sessions() -> None:
    """BDD coverage for a single autolaunch pass."""


@given("an autolaunch configuration with an empty state file", target_fixture="context")
def given_config(tmp_path: Path) -> dict[str, object]:
    state_dir = tmp_path / "state"
    config = AppConfig(
        tether_bin="tether",
        state_dir=state_dir,
        poll_seconds=10,
        command_timeout_seconds=60,
        tether_host="127.0.0.1",
        tether_port=8787,
        tether_dev=True,
        start_tether=False,
        platform_mode="fixed",
        platform="telegram",
        platform_preference=("discord", "slack"),
        available_platforms=(),
        runner_types=("codex", "opencode"),
        seen_sessions_file=state_dir / "seen_sessions.txt",
        session_state_file=state_dir / "sessions.json",
        log_file=state_dir / "daemon.log",
        decision_log_file=state_dir / "decision-log.jsonl",
        failure_digest_file=state_dir / "failure-digest.json",
        status_snapshot_file=state_dir / "status-snapshot.json",
        config_env_path=tmp_path / "config.env",
        env_files=(tmp_path / ".env", tmp_path / "config.env"),
        discord_bot_token=None,
        discord_require_pairing=False,
        discord_pairing_code=None,
        discord_guild_id=None,
        discord_channel_id=None,
        discord_machine_channel_create=False,
        discord_machine_channel_prefix="🖥️",
        discord_machine_name="bdd-machine",
        discord_machine_channel_category_id=None,
        discord_pairing_automation_enabled=False,
        discord_pairing_automation_token=None,
        discord_pairing_log_path=state_dir / "daemon.log",
        discord_pairing_state_file=state_dir / "discord-pairing-automation.json",
        discord_pairing_resources_prompt_regex=r"(?i)resources.*maintaining this session",
        discord_pairing_resources_reply="yes",
        runtime_env={},
    )
    return {"config": config, "calls": []}


@given("discoverable external sessions for codex and opencode")
def given_sessions(context: dict[str, object]) -> None:
    calls: list[list[str]] = context["calls"]  # type: ignore[assignment]

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        calls.append(args)
        if args == ["tether", "list", "--external", "-r", "codex"]:
            return subprocess.CompletedProcess(args, 0, stdout="codexA codex /tmp/a\n", stderr="")
        if args == ["tether", "list", "--external", "-r", "opencode"]:
            return subprocess.CompletedProcess(args, 0, stdout="openB opencode /tmp/b\n", stderr="")
        if args[:2] == ["tether", "attach"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout=f"Attached session sess_{args[2]}\n",
                stderr="",
            )
        raise AssertionError(f"Unexpected args: {args}")

    context["runner"] = fake_runner


@when("one autolaunch pass runs")
def when_run_once(context: dict[str, object]) -> None:
    config: AppConfig = context["config"]  # type: ignore[assignment]
    runner = context["runner"]  # type: ignore[assignment]
    context["summary"] = run_once(
        config,
        runner=runner,
        is_healthy=lambda _config: True,
        background_starter=lambda _args, _log: None,
        sleeper=lambda _seconds: None,
    )


@then("the unseen sessions are attached")
def then_attached(context: dict[str, object]) -> None:
    summary: RunSummary = context["summary"]  # type: ignore[assignment]
    calls: list[list[str]] = context["calls"]  # type: ignore[assignment]
    assert summary.attached_ids == ("codexA", "openB")
    assert ["tether", "attach", "codexA", "-p", "telegram"] in calls
    assert ["tether", "attach", "openB", "-p", "telegram"] in calls


@then("the session state file records the attached session IDs")
def then_state_file(context: dict[str, object]) -> None:
    config: AppConfig = context["config"]  # type: ignore[assignment]
    state_payload = config.session_state_file.read_text(encoding="utf-8")
    assert '"codexA"' in state_payload
    assert '"openB"' in state_payload
    assert '"tether_session_id": "sess_codexA"' in state_payload
