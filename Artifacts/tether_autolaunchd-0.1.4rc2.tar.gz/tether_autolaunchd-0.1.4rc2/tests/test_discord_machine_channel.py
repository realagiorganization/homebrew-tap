from __future__ import annotations

from tether_autolaunchd.discord_machine_channel import (
    build_machine_channel_name,
    ensure_machine_channel,
    slugify_machine_name,
)


def test_slugify_machine_name_normalizes_hostnames() -> None:
    assert slugify_machine_name("Kali_ThinkPad 1") == "kali-thinkpad-1"


def test_build_machine_channel_name_uses_emoji_prefix() -> None:
    assert build_machine_channel_name("kali-thinkpad1", "🧠") == "🧠-kali-thinkpad1"


def test_ensure_machine_channel_reuses_existing_matching_channel() -> None:
    calls: list[tuple[str, str, dict[str, object] | None]] = []

    def fake_request(method: str, path: str, bot_token: str, payload: dict[str, object] | None):
        calls.append((method, path, payload))
        assert bot_token == "bot-token"
        if method == "GET":
            return [
                {"id": "111", "name": "🖥️-kali-thinkpad1", "type": 0, "parent_id": None},
            ]
        raise AssertionError("create should not be called when channel exists")

    result = ensure_machine_channel(
        bot_token="bot-token",
        guild_id="guild-123",
        machine_name="kali-thinkpad1",
        request_json=fake_request,
    )

    assert result.channel_id == "111"
    assert result.created is False
    assert calls == [("GET", "/guilds/guild-123/channels", None)]


def test_ensure_machine_channel_creates_missing_channel() -> None:
    calls: list[tuple[str, str, dict[str, object] | None]] = []

    def fake_request(method: str, path: str, bot_token: str, payload: dict[str, object] | None):
        calls.append((method, path, payload))
        assert bot_token == "bot-token"
        if method == "GET":
            return []
        if method == "POST":
            return {"id": "222", "name": payload["name"], "type": 0}
        raise AssertionError(f"Unexpected method: {method}")

    result = ensure_machine_channel(
        bot_token="bot-token",
        guild_id="guild-123",
        machine_name="Kali ThinkPad 1",
        category_id="cat-9",
        request_json=fake_request,
    )

    assert result.channel_id == "222"
    assert result.channel_name == "🖥️-kali-thinkpad-1"
    assert result.created is True
    assert calls == [
        ("GET", "/guilds/guild-123/channels", None),
        (
            "POST",
            "/guilds/guild-123/channels",
            {
                "name": "🖥️-kali-thinkpad-1",
                "type": 0,
                "topic": "Tether control channel for Kali ThinkPad 1",
                "parent_id": "cat-9",
            },
        ),
    ]
