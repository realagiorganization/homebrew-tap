from __future__ import annotations

from pathlib import Path

from tether_autolaunchd.config import load_config
from tether_autolaunchd.discord_machine_channel import DiscordMachineChannelResult
from tether_autolaunchd.runtime import _prepare_runtime_config


def _base_env(tmp_path: Path) -> dict[str, str]:
    return {
        "HOME": str(tmp_path),
        "TETHER_BRIDGE_REACTION_NEW_SESSION_ENABLED": "1",
        "TETHER_BRIDGE_REACTION_NEW_SESSION_EMOJI": "✅",
    }


def test_load_config_preserves_future_reaction_shortcut_env_keys(tmp_path: Path) -> None:
    config = load_config(env=_base_env(tmp_path), env_file_paths=())

    assert config.runtime_env["TETHER_BRIDGE_REACTION_NEW_SESSION_ENABLED"] == "1"
    assert config.runtime_env["TETHER_BRIDGE_REACTION_NEW_SESSION_EMOJI"] == "✅"


def test_prepare_runtime_config_keeps_reaction_shortcut_env_during_discord_bootstrap(
    monkeypatch,
    tmp_path: Path,
) -> None:
    env = _base_env(tmp_path)
    env.update(
        {
            "DISCORD_BOT_TOKEN": "bot-token",
            "DISCORD_GUILD_ID": "guild-123",
            "TAD_DISCORD_MACHINE_CHANNEL_CREATE": "true",
        }
    )
    config = load_config(env=env, env_file_paths=())

    monkeypatch.setattr(
        "tether_autolaunchd.runtime.ensure_machine_channel",
        lambda **_kwargs: DiscordMachineChannelResult(
            channel_id="channel-777",
            channel_name="🖥️-test-machine",
            created=False,
        ),
    )

    prepared_config, channel_result = _prepare_runtime_config(config)

    assert channel_result is not None
    assert prepared_config.runtime_env["DISCORD_CHANNEL_ID"] == "channel-777"
    assert prepared_config.runtime_env["TETHER_BRIDGE_REACTION_NEW_SESSION_ENABLED"] == "1"
    assert prepared_config.runtime_env["TETHER_BRIDGE_REACTION_NEW_SESSION_EMOJI"] == "✅"


def test_prepare_runtime_config_sets_codex_bin_from_user_local_bin(tmp_path: Path) -> None:
    codex_bin = tmp_path / ".local" / "bin" / "codex"
    codex_bin.parent.mkdir(parents=True)
    codex_bin.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
    codex_bin.chmod(codex_bin.stat().st_mode | 0o111)

    config = load_config(env=_base_env(tmp_path), env_file_paths=())

    prepared_config, _channel_result = _prepare_runtime_config(config)

    assert prepared_config.runtime_env["TETHER_CODEX_SIDECAR_CODEX_BIN"] == str(
        codex_bin
    )


def test_prepare_runtime_config_keeps_explicit_codex_bin(
    monkeypatch,
    tmp_path: Path,
) -> None:
    env = _base_env(tmp_path)
    env["TETHER_CODEX_SIDECAR_CODEX_BIN"] = "/opt/codex/bin/codex"
    config = load_config(env=env, env_file_paths=())

    monkeypatch.setattr(
        "tether_autolaunchd.runtime.shutil.which",
        lambda *_args, **_kwargs: None,
    )

    prepared_config, _channel_result = _prepare_runtime_config(config)

    assert prepared_config.runtime_env["TETHER_CODEX_SIDECAR_CODEX_BIN"] == "/opt/codex/bin/codex"


def test_prepare_runtime_config_sets_codex_bin_from_path(
    monkeypatch,
    tmp_path: Path,
) -> None:
    config = load_config(env=_base_env(tmp_path), env_file_paths=())

    monkeypatch.setattr(
        "tether_autolaunchd.runtime.shutil.which",
        lambda name, path=None: (
            "/usr/bin/codex" if name == "codex" and path is not None else None
        ),
    )

    prepared_config, _channel_result = _prepare_runtime_config(config)

    assert prepared_config.runtime_env["TETHER_CODEX_SIDECAR_CODEX_BIN"] == "/usr/bin/codex"


def test_prepare_runtime_config_defaults_to_opencode_on_termux(tmp_path: Path) -> None:
    env = _base_env(tmp_path)
    env["TERMUX_VERSION"] = "0.118.0"
    config = load_config(env=env, env_file_paths=())

    prepared_config, _channel_result = _prepare_runtime_config(config)

    assert prepared_config.runtime_env["TETHER_DEFAULT_AGENT_ADAPTER"] == "opencode"


def test_prepare_runtime_config_keeps_explicit_adapter_on_termux(tmp_path: Path) -> None:
    env = _base_env(tmp_path)
    env["TERMUX_VERSION"] = "0.118.0"
    env["TETHER_DEFAULT_AGENT_ADAPTER"] = "codex_sdk_sidecar"
    config = load_config(env=env, env_file_paths=())

    prepared_config, _channel_result = _prepare_runtime_config(config)

    assert prepared_config.runtime_env["TETHER_DEFAULT_AGENT_ADAPTER"] == "codex_sdk_sidecar"
