from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _fake_tether_bin() -> Path:
    return (_repo_root() / "tests" / "fixtures" / "fake_tether_cli.py").resolve()


def _clean_process_env() -> dict[str, str]:
    return {
        key: value
        for key, value in os.environ.items()
        if not (
            key.startswith("TAD_")
            or key.startswith("DISCORD_")
            or key.startswith("SLACK_")
            or key in {"HOME", "XDG_CONFIG_HOME", "XDG_STATE_HOME"}
        )
    }


def _build_installed_cli_env(
    tmp_path: Path,
    *,
    env_file_contents: str = "",
    **overrides: str,
) -> tuple[dict[str, str], Path, Path, Path]:
    home_dir = tmp_path / "home"
    xdg_config_home = home_dir / ".config"
    xdg_state_home = home_dir / ".local" / "state"
    state_dir = tmp_path / "state"
    attach_log = tmp_path / "attach.jsonl"
    sync_log = tmp_path / "sync.jsonl"
    env_file = tmp_path / "isolated.env"

    xdg_config_home.mkdir(parents=True, exist_ok=True)
    xdg_state_home.mkdir(parents=True, exist_ok=True)
    env_file.write_text(env_file_contents, encoding="utf-8")

    env = _clean_process_env()
    env.update(
        {
            "HOME": str(home_dir),
            "XDG_CONFIG_HOME": str(xdg_config_home),
            "XDG_STATE_HOME": str(xdg_state_home),
            "TAD_ENV_FILES": str(env_file),
            "TAD_TETHER_BIN": str(_fake_tether_bin()),
            "TAD_START_TETHER": "false",
            "TAD_RUNNER_TYPES": "codex",
            "TAD_STATE_DIR": str(state_dir),
            "TAD_FAKE_TETHER_SESSIONS": "codexA",
            "TAD_FAKE_TETHER_ATTACH_LOG": str(attach_log),
            "TAD_FAKE_TETHER_SYNC_LOG": str(sync_log),
        }
    )
    env.update({key: str(value) for key, value in overrides.items()})
    return env, state_dir, attach_log, sync_log


def _run_once(env: dict[str, str]) -> dict[str, object]:
    result = subprocess.run(
        ["tether-autolaunchd", "once"],
        check=True,
        capture_output=True,
        text=True,
        env=env,
    )
    return json.loads(result.stdout)


def _read_jsonl(path: Path) -> list[dict[str, object]]:
    if not path.exists():
        return []
    return [
        json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()
    ]


def test_installed_cli_respects_env_precedence(tmp_path: Path) -> None:
    env, _state_dir, attach_log, _sync_log = _build_installed_cli_env(
        tmp_path,
        env_file_contents="TAD_PLATFORM=slack\n",
        TAD_PLATFORM="discord",
    )

    payload = _run_once(env)
    attach_entries = _read_jsonl(attach_log)

    assert payload["resolved_platform"] == "discord"
    assert attach_entries == [
        {
            "external_session_id": "codexA",
            "platform": "discord",
            "tether_session_id": "sess_codexA",
        }
    ]


def test_installed_cli_supports_platform_mode_off(tmp_path: Path) -> None:
    env, _state_dir, attach_log, _sync_log = _build_installed_cli_env(
        tmp_path,
        TAD_PLATFORM_MODE="off",
    )

    payload = _run_once(env)
    attach_entries = _read_jsonl(attach_log)

    assert payload["resolved_platform"] is None
    assert attach_entries == [
        {
            "external_session_id": "codexA",
            "platform": None,
            "tether_session_id": "sess_codexA",
        }
    ]


def test_installed_cli_supports_platform_mode_fixed(tmp_path: Path) -> None:
    env, _state_dir, attach_log, _sync_log = _build_installed_cli_env(
        tmp_path,
        TAD_PLATFORM_MODE="fixed",
        TAD_PLATFORM="slack",
    )

    payload = _run_once(env)
    attach_entries = _read_jsonl(attach_log)

    assert payload["resolved_platform"] == "slack"
    assert attach_entries == [
        {
            "external_session_id": "codexA",
            "platform": "slack",
            "tether_session_id": "sess_codexA",
        }
    ]


def test_installed_cli_supports_platform_mode_auto(tmp_path: Path) -> None:
    env, _state_dir, attach_log, _sync_log = _build_installed_cli_env(
        tmp_path,
        TAD_PLATFORM_MODE="auto",
        DISCORD_BOT_TOKEN="discord-token",
        DISCORD_CHANNEL_ID="123456",
        SLACK_BOT_TOKEN="slack-token",
    )

    payload = _run_once(env)
    attach_entries = _read_jsonl(attach_log)

    assert payload["resolved_platform"] == "discord"
    assert attach_entries == [
        {
            "external_session_id": "codexA",
            "platform": "discord",
            "tether_session_id": "sess_codexA",
        }
    ]


def test_installed_cli_persists_json_state_between_runs(tmp_path: Path) -> None:
    env, state_dir, attach_log, sync_log = _build_installed_cli_env(
        tmp_path,
        TAD_PLATFORM="discord",
    )

    first_payload = _run_once(env)
    second_payload = _run_once(env)

    attach_entries = _read_jsonl(attach_log)
    sync_entries = _read_jsonl(sync_log)
    state = json.loads((state_dir / "sessions.json").read_text(encoding="utf-8"))

    assert first_payload["attached_ids"] == ["codexA"]
    assert first_payload["synced_ids"] == []
    assert second_payload["attached_ids"] == []
    assert second_payload["synced_ids"] == ["codexA"]
    assert attach_entries == [
        {
            "external_session_id": "codexA",
            "platform": "discord",
            "tether_session_id": "sess_codexA",
        }
    ]
    assert sync_entries == [{"tether_session_id": "sess_codexA"}]
    assert state["sessions"]["codexA"]["attached_platform"] == "discord"
    assert state["sessions"]["codexA"]["attach_status"] == "attached"
    assert state["sessions"]["codexA"]["tether_session_id"] == "sess_codexA"
