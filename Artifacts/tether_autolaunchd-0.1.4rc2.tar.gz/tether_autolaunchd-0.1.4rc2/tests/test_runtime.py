from __future__ import annotations

import json
import os
import socket
import subprocess
import urllib.error
from pathlib import Path

from tether_autolaunchd.config import AppConfig
from tether_autolaunchd.runtime import (
    apply_runtime_env,
    build_tether_start_command,
    default_runner,
    ensure_tether_discord_bridge_feedback_patch,
    healthcheck,
    is_tether_port_open,
    load_session_state,
    load_status_snapshot,
    parse_attached_session_id,
    parse_external_session_ids,
    patch_tether_discord_bridge_source,
    render_env_example,
    render_user_service,
    resolve_platform,
    resolve_tether_discord_bridge_path,
    run_once,
)


def make_config(tmp_path: Path, **overrides: object) -> AppConfig:
    state_dir = tmp_path / "state"
    values: dict[str, object] = {
        "tether_bin": "tether",
        "state_dir": state_dir,
        "poll_seconds": 10,
        "command_timeout_seconds": 60,
        "tether_host": "127.0.0.1",
        "tether_port": 8787,
        "tether_dev": True,
        "start_tether": True,
        "platform_mode": "fixed",
        "platform": "telegram",
        "platform_preference": ("discord", "slack"),
        "available_platforms": (),
        "runner_types": ("codex", "opencode"),
        "seen_sessions_file": state_dir / "seen_sessions.txt",
        "session_state_file": state_dir / "sessions.json",
        "log_file": state_dir / "daemon.log",
        "decision_log_file": state_dir / "decision-log.jsonl",
        "failure_digest_file": state_dir / "failure-digest.json",
        "status_snapshot_file": state_dir / "status-snapshot.json",
        "config_env_path": tmp_path / "config.env",
        "env_files": (tmp_path / ".env", tmp_path / "config.env"),
        "discord_bot_token": None,
        "discord_require_pairing": False,
        "discord_pairing_code": None,
        "discord_guild_id": None,
        "discord_channel_id": None,
        "discord_machine_channel_create": False,
        "discord_machine_channel_prefix": "🖥️",
        "discord_machine_name": "test-machine",
        "discord_machine_channel_category_id": None,
        "discord_pairing_automation_enabled": False,
        "discord_pairing_automation_token": None,
        "discord_pairing_log_path": state_dir / "daemon.log",
        "discord_pairing_state_file": state_dir / "discord-pairing-automation.json",
        "discord_pairing_resources_prompt_regex": r"(?i)resources.*maintaining this session",
        "discord_pairing_resources_reply": "yes",
        "runtime_env": {},
    }
    values.update(overrides)
    return AppConfig(**values)


def read_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def make_fake_tether_install(tmp_path: Path, bot_source: str) -> tuple[Path, Path]:
    tether_bin = tmp_path / "venv" / "bin" / "tether"
    tether_bin.parent.mkdir(parents=True, exist_ok=True)
    tether_bin.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
    tether_bin.chmod(tether_bin.stat().st_mode | 0o111)

    bridge_path = (
        tmp_path
        / "venv"
        / "lib"
        / "python3.12"
        / "site-packages"
        / "tether"
        / "bridges"
        / "discord"
        / "bot.py"
    )
    bridge_path.parent.mkdir(parents=True, exist_ok=True)
    bridge_path.write_text(bot_source, encoding="utf-8")
    return tether_bin, bridge_path


def test_parse_external_session_ids_skips_headers() -> None:
    output = """ID           TYPE   DIRECTORY
──────────── ────── ─────────
abc123       codex  /tmp/a
xyz789       pi     /tmp/b
"""
    assert parse_external_session_ids(output) == ("abc123", "xyz789")


def test_parse_external_session_ids_skips_no_session_lines() -> None:
    output = """No external sessions found for runner pi
ses123 codex /tmp/a
"""
    assert parse_external_session_ids(output) == ("ses123",)


def test_parse_attached_session_id_extracts_tether_session_id() -> None:
    assert parse_attached_session_id("Attached session sess_codex123\n") == "sess_codex123"
    assert parse_attached_session_id("attached session sess_open456\n") == "sess_open456"
    assert parse_attached_session_id("attached\n") is None


def test_patch_tether_discord_bridge_source_inserts_feedback_message() -> None:
    source = (
        '            ) and self._should_defer_new_message_to_reaction(text):\n'
        "                return\n"
    )

    patched_source, status = patch_tether_discord_bridge_source(source)

    assert status == "patched"
    assert "Multi-line `!new` requests start via reaction here." in patched_source
    assert "React to your original message with {self._reaction_new_session_emoji}" in (
        patched_source
    )


def test_patch_tether_discord_bridge_source_is_idempotent() -> None:
    source = (
        '            ) and self._should_defer_new_message_to_reaction(text):\n'
        "                await message.channel.send(\n"
        '                    "ℹ️ Multi-line `!new` requests start via reaction here.\\n"\n'
        '                    f"React to your original message with '
        '{self._reaction_new_session_emoji} "\n'
        '                    "to create the session."\n'
        "                )\n"
        "                return\n"
    )

    patched_source, status = patch_tether_discord_bridge_source(source)

    assert status == "already_patched"
    assert patched_source == source


def test_resolve_tether_discord_bridge_path_from_venv_bin(tmp_path: Path) -> None:
    tether_bin, bridge_path = make_fake_tether_install(tmp_path, "pass\n")

    assert resolve_tether_discord_bridge_path(str(tether_bin)) == bridge_path


def test_ensure_tether_discord_bridge_feedback_patch_updates_installed_source(
    tmp_path: Path,
) -> None:
    tether_bin, bridge_path = make_fake_tether_install(
        tmp_path,
        (
            '            ) and self._should_defer_new_message_to_reaction(text):\n'
            "                return\n"
        ),
    )
    config = make_config(tmp_path, tether_bin=str(tether_bin))

    status, patched_path = ensure_tether_discord_bridge_feedback_patch(config)

    assert status == "patched"
    assert patched_path == bridge_path
    assert "Multi-line `!new` requests start via reaction here." in bridge_path.read_text(
        encoding="utf-8"
    )


def test_build_tether_start_command_adds_dev_flag(tmp_path: Path) -> None:
    config = make_config(tmp_path)
    assert build_tether_start_command(config) == [
        "tether",
        "start",
        "--host",
        "127.0.0.1",
        "--port",
        "8787",
        "--dev",
    ]


def test_default_runner_passes_timeout_to_subprocess(monkeypatch) -> None:
    seen: dict[str, object] = {}

    def fake_run(*args, **kwargs):
        seen["args"] = args[0]
        seen["timeout"] = kwargs["timeout"]
        return subprocess.CompletedProcess(args[0], 0, stdout="", stderr="")

    monkeypatch.setattr("tether_autolaunchd.runtime.subprocess.run", fake_run)

    result = default_runner(["tether", "list"], timeout_seconds=42)

    assert result.returncode == 0
    assert seen["args"] == ["tether", "list"]
    assert seen["timeout"] == 42


def test_resolve_platform_prefers_available_auto_target(tmp_path: Path) -> None:
    config = make_config(
        tmp_path,
        platform_mode="auto",
        platform=None,
        available_platforms=("slack", "discord"),
    )
    assert resolve_platform(config) == "discord"


def test_run_once_starts_server_and_attaches_unseen_sessions(monkeypatch, tmp_path: Path) -> None:
    config = make_config(tmp_path)
    calls: list[list[str]] = []
    healthy_checks = {"count": 0}
    monkeypatch.setattr("tether_autolaunchd.runtime.is_tether_port_open", lambda _config: False)

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        calls.append(args)
        if args[:3] == ["tether", "list", "--external"]:
            runner = args[-1]
            session_id = "codex123" if runner == "codex" else "open456"
            return subprocess.CompletedProcess(
                args,
                0,
                stdout=f"{session_id} runner /tmp/demo\n",
                stderr="",
            )
        if args[:2] == ["tether", "attach"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout=f"Attached session sess_{args[2]}\n",
                stderr="",
            )
        raise AssertionError(f"Unexpected command: {args}")

    started_commands: list[list[str]] = []

    def fake_background(args: list[str], log_file: Path) -> None:
        started_commands.append(args)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text("started\n", encoding="utf-8")

    def fake_healthcheck(_: AppConfig) -> bool:
        healthy_checks["count"] += 1
        return healthy_checks["count"] > 1

    summary = run_once(
        config,
        runner=fake_runner,
        is_healthy=fake_healthcheck,
        background_starter=fake_background,
        sleeper=lambda _seconds: None,
    )

    assert summary.started_tether is True
    assert summary.tether_healthy is True
    assert summary.discovered_ids == ("codex123", "open456")
    assert summary.attached_ids == ("codex123", "open456")
    assert started_commands == [build_tether_start_command(config)]
    assert ["tether", "attach", "codex123", "-p", "telegram"] in calls
    assert ["tether", "attach", "open456", "-p", "telegram"] in calls
    assert config.seen_sessions_file.read_text(encoding="utf-8").splitlines() == [
        "codex123",
        "open456",
    ]
    state = read_json(config.session_state_file)
    assert state["sessions"]["codex123"]["attached_platform"] == "telegram"
    assert state["sessions"]["open456"]["attach_status"] == "attached"
    assert state["sessions"]["codex123"]["tether_session_id"] == "sess_codex123"


def test_run_once_applies_tether_discord_bridge_patch(tmp_path: Path) -> None:
    tether_bin, bridge_path = make_fake_tether_install(
        tmp_path,
        (
            "        if (\n"
            "            self._channel_id\n"
            '            and text.startswith("!")\n'
            "        ):\n"
            '            if text.lower().startswith(\n'
            '                "!new"\n'
            "            ) and self._should_defer_new_message_to_reaction(text):\n"
            "                return\n"
            "            await self._dispatch_command(message, text)\n"
            "            return\n"
        ),
    )
    config = make_config(
        tmp_path,
        tether_bin=str(tether_bin),
        platform_mode="off",
        platform=None,
        runner_types=(),
        start_tether=False,
    )

    summary = run_once(
        config,
        runner=lambda _args: (_ for _ in ()).throw(AssertionError("runner should not be used")),
        is_healthy=lambda _config: True,
        background_starter=lambda _args, _log: None,
        sleeper=lambda _seconds: None,
    )

    events = [
        json.loads(line)
        for line in config.decision_log_file.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert summary.tether_healthy is True
    assert "Multi-line `!new` requests start via reaction here." in bridge_path.read_text(
        encoding="utf-8"
    )
    assert any(event["event"] == "tether_discord_bridge_patch_applied" for event in events)


def test_is_tether_port_open_detects_listener(tmp_path: Path) -> None:
    config = make_config(tmp_path)
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.bind((config.tether_host, 0))
    listener.listen()
    host, port = listener.getsockname()
    config = make_config(tmp_path, tether_host=host, tether_port=port)
    try:
        assert is_tether_port_open(config) is True
    finally:
        listener.close()


def test_healthcheck_uses_proxyless_opener(monkeypatch, tmp_path: Path) -> None:
    config = make_config(tmp_path)
    seen: dict[str, object] = {}

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            return None

        def read(self) -> bytes:
            return b'{"ok": true}'

    class FakeOpener:
        def open(self, request, timeout: int):
            seen["url"] = request.full_url
            seen["timeout"] = timeout
            return FakeResponse()

    monkeypatch.setattr(
        "tether_autolaunchd.runtime.urllib.request.ProxyHandler",
        lambda proxies: ("proxy_handler", proxies),
    )

    def fake_build_opener(handler):
        seen["handler"] = handler
        return FakeOpener()

    monkeypatch.setattr(
        "tether_autolaunchd.runtime.urllib.request.build_opener",
        fake_build_opener,
    )

    assert healthcheck(config) is True
    assert seen["handler"] == ("proxy_handler", {})
    assert seen["url"] == "http://127.0.0.1:8787/api/health"
    assert seen["timeout"] == 2


def test_healthcheck_falls_back_to_tether_cli_when_http_is_unavailable(
    monkeypatch,
    tmp_path: Path,
) -> None:
    config = make_config(tmp_path, tether_bin="/tmp/fake-tether", start_tether=False)

    def fake_build_opener(_handler):
        class FakeOpener:
            def open(self, _request, timeout: int):
                raise urllib.error.URLError("down")

        return FakeOpener()

    seen: dict[str, object] = {}

    def fake_run(*args, **kwargs):
        seen["args"] = args[0]
        seen["timeout"] = kwargs["timeout"]
        return subprocess.CompletedProcess(args[0], 0, stdout='{"ok": true}\n', stderr="")

    monkeypatch.setattr(
        "tether_autolaunchd.runtime.urllib.request.build_opener",
        fake_build_opener,
    )
    monkeypatch.setattr("tether_autolaunchd.runtime.subprocess.run", fake_run)

    assert healthcheck(config) is True
    assert seen["args"] == ["/tmp/fake-tether", "health"]
    assert seen["timeout"] == 5


def test_healthcheck_returns_false_when_http_and_cli_health_both_fail(
    monkeypatch,
    tmp_path: Path,
) -> None:
    config = make_config(tmp_path, tether_bin="/tmp/fake-tether", start_tether=False)

    def fake_build_opener(_handler):
        class FakeOpener:
            def open(self, _request, timeout: int):
                raise urllib.error.URLError("down")

        return FakeOpener()

    monkeypatch.setattr(
        "tether_autolaunchd.runtime.urllib.request.build_opener",
        fake_build_opener,
    )

    def fake_run(*args, **kwargs):
        raise subprocess.CalledProcessError(1, args[0], stderr="boom")

    monkeypatch.setattr("tether_autolaunchd.runtime.subprocess.run", fake_run)

    assert healthcheck(config) is False


def test_run_once_does_not_restart_tether_when_port_is_already_bound(tmp_path: Path) -> None:
    config = make_config(tmp_path, runner_types=("codex",))
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.bind((config.tether_host, 0))
    listener.listen()
    host, port = listener.getsockname()
    config = make_config(tmp_path, tether_host=host, tether_port=port, runner_types=("codex",))
    started_commands: list[list[str]] = []
    try:
        summary = run_once(
            config,
            runner=lambda _args: (_ for _ in ()).throw(AssertionError("runner should not be used")),
            is_healthy=lambda _config: False,
            background_starter=lambda args, _log: started_commands.append(list(args)),
            sleeper=lambda _seconds: None,
        )
    finally:
        listener.close()

    assert summary.started_tether is False
    assert summary.tether_healthy is False
    assert summary.discovered_ids == ()
    assert summary.attached_ids == ()
    assert started_commands == []


def test_run_once_uses_auto_platform_and_syncs_already_attached_sessions(tmp_path: Path) -> None:
    config = make_config(
        tmp_path,
        platform_mode="auto",
        platform=None,
        available_platforms=("discord",),
    )
    config.session_state_file.parent.mkdir(parents=True, exist_ok=True)
    config.session_state_file.write_text(
        json.dumps(
            {
                "sessions": {
                    "codex123": {
                        "attached_platform": "discord",
                        "attach_status": "attached",
                        "first_seen_at": "2026-03-31T00:00:00Z",
                        "last_attempt_at": "2026-03-31T00:00:00Z",
                        "runner_type": "codex",
                        "tether_session_id": "sess_codex123",
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    calls: list[list[str]] = []

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        calls.append(args)
        if args[:3] == ["tether", "list", "--external"]:
            return subprocess.CompletedProcess(args, 0, stdout="codex123 codex /tmp/a\n", stderr="")
        if args == ["tether", "sync", "sess_codex123"]:
            return subprocess.CompletedProcess(args, 0, stdout="synced\n", stderr="")
        if args[:2] == ["tether", "attach"]:
            raise AssertionError("attach should not run when tether_session_id is already tracked")
        raise AssertionError(f"Unexpected command: {args}")

    summary = run_once(
        config,
        runner=fake_runner,
        is_healthy=lambda _config: True,
        background_starter=lambda _args, _log: None,
        sleeper=lambda _seconds: None,
    )

    assert summary.attached_ids == ()
    assert summary.synced_ids == ("codex123",)
    assert summary.skipped_ids == ()
    assert calls == [
        ["tether", "list", "--external", "-r", "codex"],
        ["tether", "list", "--external", "-r", "opencode"],
        ["tether", "sync", "sess_codex123"],
    ]


def test_run_once_recovers_missing_tether_binding_then_syncs(tmp_path: Path) -> None:
    config = make_config(
        tmp_path,
        platform_mode="auto",
        platform=None,
        available_platforms=("discord",),
        runner_types=("codex",),
    )
    config.session_state_file.parent.mkdir(parents=True, exist_ok=True)
    config.session_state_file.write_text(
        json.dumps(
            {
                "sessions": {
                    "codex123": {
                        "attached_platform": "discord",
                        "attach_status": "attached",
                        "first_seen_at": "2026-03-31T00:00:00Z",
                        "last_attempt_at": "2026-03-31T00:00:00Z",
                        "runner_type": "codex",
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    calls: list[list[str]] = []

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        calls.append(args)
        if args == ["tether", "list", "--external", "-r", "codex"]:
            return subprocess.CompletedProcess(args, 0, stdout="codex123 codex /tmp/a\n", stderr="")
        if args == ["tether", "attach", "codex123", "-p", "discord"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="Attached session sess_codex123\n",
                stderr="",
            )
        if args == ["tether", "sync", "sess_codex123"]:
            return subprocess.CompletedProcess(args, 0, stdout="synced\n", stderr="")
        raise AssertionError(f"Unexpected command: {args}")

    summary = run_once(
        config,
        runner=fake_runner,
        is_healthy=lambda _config: True,
        background_starter=lambda _args, _log: None,
        sleeper=lambda _seconds: None,
    )

    state = load_session_state(config.session_state_file)
    assert summary.attached_ids == ()
    assert summary.synced_ids == ("codex123",)
    assert state["codex123"]["tether_session_id"] == "sess_codex123"
    assert calls == [
        ["tether", "list", "--external", "-r", "codex"],
        ["tether", "attach", "codex123", "-p", "discord"],
        ["tether", "sync", "sess_codex123"],
    ]


def test_run_once_records_failures_without_stopping_other_sessions(tmp_path: Path) -> None:
    config = make_config(
        tmp_path,
        platform_mode="auto",
        platform=None,
        available_platforms=("slack",),
        runner_types=("codex",),
    )
    calls: list[list[str]] = []

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        calls.append(args)
        if args[:3] == ["tether", "list", "--external"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="bad1 codex /tmp/a\ngood2 codex /tmp/b\n",
                stderr="",
            )
        if args == ["tether", "attach", "bad1", "-p", "slack"]:
            raise subprocess.CalledProcessError(1, args, stderr="boom")
        if args == ["tether", "attach", "good2", "-p", "slack"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="Attached session sess_good2\n",
                stderr="",
            )
        raise AssertionError(f"Unexpected command: {args}")

    summary = run_once(
        config,
        runner=fake_runner,
        is_healthy=lambda _config: True,
        background_starter=lambda _args, _log: None,
        sleeper=lambda _seconds: None,
    )

    assert summary.attached_ids == ("good2",)
    assert summary.failed_ids == ("bad1",)
    state = load_session_state(config.session_state_file)
    assert state["bad1"]["attach_status"] == "failed"
    assert state["bad1"]["attached_platform"] == "slack"
    assert state["good2"]["attach_status"] == "attached"
    assert state["good2"]["tether_session_id"] == "sess_good2"
    assert config.seen_sessions_file.read_text(encoding="utf-8").splitlines() == ["good2"]


def test_run_once_writes_observability_artifacts(tmp_path: Path) -> None:
    config = make_config(
        tmp_path,
        platform_mode="auto",
        platform=None,
        available_platforms=("discord",),
        runner_types=("codex",),
    )
    config.session_state_file.parent.mkdir(parents=True, exist_ok=True)
    config.session_state_file.write_text(
        json.dumps(
            {
                "sessions": {
                    "old2": {
                        "attached_platform": "discord",
                        "attach_status": "attached",
                        "first_seen_at": "2026-03-31T00:00:00Z",
                        "last_attempt_at": "2026-03-31T00:00:00Z",
                        "runner_type": "codex",
                        "tether_session_id": "sess_old2",
                    }
                }
            }
        ),
        encoding="utf-8",
    )

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        if args[:3] == ["tether", "list", "--external"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="new1 codex /tmp/a\nold2 codex /tmp/b\n",
                stderr="",
            )
        if args == ["tether", "attach", "new1", "-p", "discord"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="Attached session sess_new1\n",
                stderr="",
            )
        if args == ["tether", "sync", "sess_old2"]:
            raise subprocess.CalledProcessError(1, args, stderr="sync failed")
        raise AssertionError(f"Unexpected command: {args}")

    summary = run_once(
        config,
        runner=fake_runner,
        is_healthy=lambda _config: True,
        background_starter=lambda _args, _log: None,
        sleeper=lambda _seconds: None,
    )

    snapshot = read_json(config.status_snapshot_file)
    events = [
        json.loads(line)
        for line in config.decision_log_file.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert summary.attached_ids == ("new1",)
    assert summary.failed_ids == ("old2",)
    assert snapshot["last_pass"]["attached_count"] == 1
    assert snapshot["last_pass"]["failed_count"] == 1
    assert snapshot["failure_digest"]["totals"]["attach_succeeded"] == 1
    assert snapshot["failure_digest"]["totals"]["sync_failed"] == 1
    assert "tether_discord_pairing" in snapshot
    assert any(event["event"] == "session_attach_succeeded" for event in events)
    assert any(event["event"] == "session_sync_failed" for event in events)
    assert any(event["event"] == "pass_summary" for event in events)


def test_run_once_skips_runner_failures_and_continues(tmp_path: Path) -> None:
    config = make_config(
        tmp_path,
        platform_mode="auto",
        platform=None,
        available_platforms=("discord",),
        runner_types=("codex", "opencode"),
    )

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        if args == ["tether", "list", "--external", "-r", "codex"]:
            raise subprocess.CalledProcessError(1, args, stderr="runner failed")
        if args == ["tether", "list", "--external", "-r", "opencode"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="open456 opencode /tmp/b\n",
                stderr="",
            )
        if args == ["tether", "attach", "open456", "-p", "discord"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="Attached session sess_open456\n",
                stderr="",
            )
        raise AssertionError(f"Unexpected command: {args}")

    summary = run_once(
        config,
        runner=fake_runner,
        is_healthy=lambda _config: True,
        background_starter=lambda _args, _log: None,
        sleeper=lambda _seconds: None,
    )

    assert summary.discovered_ids == ("open456",)
    assert summary.attached_ids == ("open456",)
    assert summary.runner_failures == (("codex", "runner failed"),)


def test_run_once_skips_timeout_runner_failures_and_continues(tmp_path: Path) -> None:
    config = make_config(
        tmp_path,
        platform_mode="auto",
        platform=None,
        available_platforms=("discord",),
        runner_types=("codex", "opencode"),
        command_timeout_seconds=77,
    )

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        if args == ["tether", "list", "--external", "-r", "codex"]:
            raise subprocess.TimeoutExpired(args, config.command_timeout_seconds)
        if args == ["tether", "list", "--external", "-r", "opencode"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="open456 opencode /tmp/b\n",
                stderr="",
            )
        if args == ["tether", "attach", "open456", "-p", "discord"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="Attached session sess_open456\n",
                stderr="",
            )
        raise AssertionError(f"Unexpected command: {args}")

    summary = run_once(
        config,
        runner=fake_runner,
        is_healthy=lambda _config: True,
        background_starter=lambda _args, _log: None,
        sleeper=lambda _seconds: None,
    )

    assert summary.discovered_ids == ("open456",)
    assert summary.attached_ids == ("open456",)
    assert summary.runner_failures == (("codex", "command timed out after 77s"),)


def test_run_once_returns_empty_summary_when_tether_stays_unhealthy(
    monkeypatch,
    tmp_path: Path,
) -> None:
    config = make_config(tmp_path, runner_types=("codex",))
    started_commands: list[list[str]] = []
    monkeypatch.setattr("tether_autolaunchd.runtime.is_tether_port_open", lambda _config: False)

    summary = run_once(
        config,
        runner=lambda _args: (_ for _ in ()).throw(AssertionError("runner should not be used")),
        is_healthy=lambda _config: False,
        background_starter=lambda args, _log: started_commands.append(list(args)),
        sleeper=lambda _seconds: None,
    )

    assert summary.started_tether is True
    assert summary.tether_healthy is False
    assert summary.discovered_ids == ()
    assert summary.attached_ids == ()
    assert started_commands == [build_tether_start_command(config)]


def test_load_status_snapshot_returns_default_shape(tmp_path: Path) -> None:
    config = make_config(tmp_path)
    snapshot = load_status_snapshot(config)
    assert snapshot["decision_log_file"] == str(config.decision_log_file)
    assert snapshot["failure_digest"]["totals"]["passes"] == 0
    assert snapshot["tether_discord_pairing"]["satisfied"] is True
    assert snapshot["tether"]["healthy"] is False


def test_load_status_snapshot_reports_live_tether_pairing_state(tmp_path: Path) -> None:
    pairing_state_file = tmp_path / "discord_pairing.json"
    pairing_state_file.write_text(
        json.dumps(
            {
                "control_channel_id": "chan-999",
                "paired_user_ids": ["222", "333"],
                "pairing_code": "code",
            }
        ),
        encoding="utf-8",
    )
    snapshot = load_status_snapshot(
        make_config(
            tmp_path,
            discord_require_pairing=True,
            runtime_env={
                "DISCORD_AUTO_PAIR_USER_IDS": "222,333",
                "DISCORD_CHANNEL_ID": "chan-999",
                "TAD_TETHER_DISCORD_PAIRING_STATE_FILE": str(pairing_state_file),
            },
        )
    )
    assert snapshot["tether_discord_pairing"]["auto_pair_matches_state"] is True
    assert snapshot["tether_discord_pairing"]["control_channel_matches_config"] is True
    assert snapshot["tether_discord_pairing"]["paired_user_count"] == 2
    assert snapshot["tether_discord_pairing"]["satisfied"] is True


def test_apply_runtime_env_refreshes_managed_values(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("DISCORD_BOT_TOKEN", raising=False)
    monkeypatch.delenv("DISCORD_CHANNEL_ID", raising=False)

    first = make_config(
        tmp_path,
        runtime_env={
            "DISCORD_BOT_TOKEN": "first-token",
            "DISCORD_CHANNEL_ID": "111",
        },
    )
    apply_runtime_env(first)
    assert os.environ["DISCORD_BOT_TOKEN"] == "first-token"
    assert os.environ["DISCORD_CHANNEL_ID"] == "111"

    second = make_config(
        tmp_path,
        runtime_env={
            "DISCORD_BOT_TOKEN": "second-token",
        },
    )
    apply_runtime_env(second)
    assert os.environ["DISCORD_BOT_TOKEN"] == "second-token"
    assert "DISCORD_CHANNEL_ID" not in os.environ


def test_run_once_applies_runtime_env_before_attach(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("DISCORD_BOT_TOKEN", raising=False)
    monkeypatch.delenv("DISCORD_CHANNEL_ID", raising=False)
    config = make_config(
        tmp_path,
        platform_mode="auto",
        platform=None,
        available_platforms=("discord",),
        runner_types=("codex",),
        runtime_env={
            "DISCORD_BOT_TOKEN": "bot-token",
            "DISCORD_CHANNEL_ID": "123456789",
        },
    )

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        if args[:3] == ["tether", "list", "--external"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="abc123 codex /tmp/demo\n",
                stderr="",
            )
        if args == ["tether", "attach", "abc123", "-p", "discord"]:
            assert os.environ["DISCORD_BOT_TOKEN"] == "bot-token"
            assert os.environ["DISCORD_CHANNEL_ID"] == "123456789"
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="Attached session sess_abc123\n",
                stderr="",
            )
        raise AssertionError(f"Unexpected command: {args}")

    summary = run_once(
        config,
        runner=fake_runner,
        is_healthy=lambda _config: True,
        background_starter=lambda _args, _log: None,
        sleeper=lambda _seconds: None,
    )

    assert summary.attached_ids == ("abc123",)


def test_run_once_bootstraps_discord_machine_channel_before_start_and_attach(
    monkeypatch,
    tmp_path: Path,
) -> None:
    config = make_config(
        tmp_path,
        platform_mode="auto",
        platform=None,
        available_platforms=("discord",),
        runner_types=("codex",),
        discord_bot_token="bot-token",
        discord_guild_id="guild-123",
        discord_channel_id="fixed-111",
        discord_machine_channel_create=True,
        runtime_env={
            "DISCORD_BOT_TOKEN": "bot-token",
            "DISCORD_CHANNEL_ID": "fixed-111",
            "DISCORD_GUILD_ID": "guild-123",
        },
    )
    background_checks: list[str] = []
    monkeypatch.setattr("tether_autolaunchd.runtime.is_tether_port_open", lambda _config: False)

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        if args[:3] == ["tether", "list", "--external"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="abc123 codex /tmp/demo\n",
                stderr="",
            )
        if args == ["tether", "attach", "abc123", "-p", "discord"]:
            assert os.environ["DISCORD_CHANNEL_ID"] == "chan-999"
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="Attached session sess_abc123\n",
                stderr="",
            )
        raise AssertionError(f"Unexpected command: {args}")

    def fake_background(args: list[str], _log_file: Path) -> None:
        background_checks.append(os.environ["DISCORD_CHANNEL_ID"])

    def fake_ensure_machine_channel(**kwargs):
        assert kwargs["bot_token"] == "bot-token"
        assert kwargs["guild_id"] == "guild-123"
        return type(
            "Result",
            (),
            {"channel_id": "chan-999", "channel_name": "🖥️-test-machine", "created": True},
        )()

    original_health = {"count": 0}

    def fake_healthcheck(_: AppConfig) -> bool:
        original_health["count"] += 1
        return original_health["count"] > 1

    from tether_autolaunchd import runtime as runtime_mod

    saved = runtime_mod.ensure_machine_channel
    runtime_mod.ensure_machine_channel = fake_ensure_machine_channel
    try:
        summary = run_once(
            config,
            runner=fake_runner,
            is_healthy=fake_healthcheck,
            background_starter=fake_background,
            sleeper=lambda _seconds: None,
        )
    finally:
        runtime_mod.ensure_machine_channel = saved

    assert summary.attached_ids == ("abc123",)
    assert background_checks == ["chan-999"]


def test_run_once_automates_discord_pairing_from_local_log(monkeypatch, tmp_path: Path) -> None:
    config = make_config(
        tmp_path,
        platform_mode="auto",
        platform=None,
        available_platforms=("discord",),
        runner_types=("codex",),
        discord_bot_token="bot-token",
        discord_require_pairing=True,
        discord_pairing_automation_enabled=True,
        discord_pairing_automation_token="user-token",
    )

    seen: dict[str, object] = {}

    monkeypatch.setattr(
        "tether_autolaunchd.runtime.automate_pairing_from_local_log",
        lambda **kwargs: (
            seen.update(kwargs)
            or type(
                "PairingResult",
                (),
                {
                    "pair_command_sent": True,
                    "resource_reply_sent": True,
                    "dm_channel_id": "dm-123",
                },
            )()
        ),
    )

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        if args[:3] == ["tether", "list", "--external"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="abc123 codex /tmp/demo\n",
                stderr="",
            )
        if args == ["tether", "attach", "abc123", "-p", "discord"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="Attached session sess_abc123\n",
                stderr="",
            )
        raise AssertionError(f"Unexpected command: {args}")

    run_once(
        config,
        runner=fake_runner,
        is_healthy=lambda _config: True,
        background_starter=lambda _args, _log: None,
        sleeper=lambda _seconds: None,
    )

    assert seen["bot_token"] == "bot-token"
    assert seen["automation_token"] == "user-token"
    assert seen["pairing_log_path"] == config.discord_pairing_log_path
    events = config.decision_log_file.read_text(encoding="utf-8")
    assert "discord_pairing_command_sent" in events
    assert "discord_pairing_resources_reply_sent" in events


def test_run_once_logs_discord_pairing_automation_failures(monkeypatch, tmp_path: Path) -> None:
    config = make_config(
        tmp_path,
        platform_mode="auto",
        platform=None,
        available_platforms=("discord",),
        runner_types=("codex",),
        discord_bot_token="bot-token",
        discord_require_pairing=True,
        discord_pairing_automation_enabled=True,
        discord_pairing_automation_token="user-token",
    )

    monkeypatch.setattr(
        "tether_autolaunchd.runtime.automate_pairing_from_local_log",
        lambda **_kwargs: (_ for _ in ()).throw(RuntimeError("pairing failed")),
    )

    def fake_runner(args: list[str]) -> subprocess.CompletedProcess[str]:
        if args[:3] == ["tether", "list", "--external"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="abc123 codex /tmp/demo\n",
                stderr="",
            )
        if args == ["tether", "attach", "abc123", "-p", "discord"]:
            return subprocess.CompletedProcess(
                args,
                0,
                stdout="Attached session sess_abc123\n",
                stderr="",
            )
        raise AssertionError(f"Unexpected command: {args}")

    run_once(
        config,
        runner=fake_runner,
        is_healthy=lambda _config: True,
        background_starter=lambda _args, _log: None,
        sleeper=lambda _seconds: None,
    )

    assert "discord_pairing_automation_failed" in config.decision_log_file.read_text(
        encoding="utf-8"
    )


def test_load_session_state_recovers_from_invalid_json(tmp_path: Path) -> None:
    state_file = tmp_path / "state" / "sessions.json"
    state_file.parent.mkdir(parents=True, exist_ok=True)
    state_file.write_text("{not-json", encoding="utf-8")
    legacy_file = tmp_path / "state" / "seen_sessions.txt"
    legacy_file.write_text("legacy1\n", encoding="utf-8")

    state = load_session_state(state_file, legacy_seen_file=legacy_file)

    assert state["legacy1"]["attach_status"] == "attached"
    assert state["legacy1"]["attached_platform"] is None


def test_render_outputs_reference_user_service(tmp_path: Path) -> None:
    home = Path.home()
    config = make_config(
        tmp_path,
        env_files=(home / ".env", home / ".config" / "tether" / "config.env"),
        config_env_path=home / ".config" / "tether-autolaunchd" / "config.env",
    )
    service = render_user_service(config)
    assert "EnvironmentFile=-" in service
    assert "EnvironmentFile=-%h/.config/tether/config.env" in service
    environment_lines = [
        line for line in service.splitlines() if line.startswith("EnvironmentFile=")
    ]
    assert environment_lines
    assert all("/home/" not in line for line in environment_lines)
    assert "ExecStart=" in service
    assert "-m tether_autolaunchd.cli daemon" in service
    package_service = render_user_service(config, exec_start="/usr/bin/tether-autolaunchd daemon")
    assert "ExecStart=/usr/bin/tether-autolaunchd daemon" in package_service
    env_example = render_env_example()
    assert "TAD_PLATFORM_MODE=auto" in env_example
    assert "TAD_PLATFORM_PREFERENCE=discord,slack" in env_example
    assert "TAD_ENV_FILES=~/.env,~/.ENV" in env_example
    assert "TAD_COMMAND_TIMEOUT_SECONDS=60" in env_example
    assert "TAD_DISCORD_MACHINE_CHANNEL_CREATE=true" in env_example
    assert "TAD_DISCORD_PAIRING_AUTOMATION=false" in env_example
    assert "TAD_DISCORD_PAIRING_AUTOMATION_TOKEN=" in env_example
    assert "TAD_DISCORD_PAIRING_RESOURCES_REPLY=yes" in env_example
    assert "TAD_DISCORD_MACHINE_CHANNEL_PREFIX=🖥️" in env_example
    assert "DISCORD_GUILD_ID=" in env_example
    assert "DISCORD_BOT_TOKEN=" in env_example
    assert "DISCORD_CHANNEL_ID=" in env_example
    assert "DISCORD_REQUIRE_PAIRING=false" in env_example
