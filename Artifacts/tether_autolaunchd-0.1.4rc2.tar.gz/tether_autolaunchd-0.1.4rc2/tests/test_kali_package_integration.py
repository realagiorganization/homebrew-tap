from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest

from tether_autolaunchd.docker_integration import (
    load_docker_integration_config,
    plan_real_docker_bdd,
)
from tether_autolaunchd.publish import debian_package_version


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _package_deb_path() -> str:
    version_line = next(
        line
        for line in (_repo_root() / "src" / "tether_autolaunchd" / "__init__.py")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.startswith("__version__ = ")
    )
    version = version_line.split('"', 2)[1]
    return f"dist/tether-autolaunchd_{debian_package_version(version)}_all.deb"


def test_plan_real_docker_bdd_can_install_deb_in_kali(tmp_path: Path) -> None:
    deb_path = _package_deb_path()
    config = load_docker_integration_config(
        env={
            "TAD_DOCKER_MOCK": "false",
            "TAD_DOCKER_INSTALL_DEB": "true",
            "TAD_DOCKER_TETHER_IMAGE": "ghcr.io/example/tether:test",
            "TAD_DOCKER_DEB_PATH": deb_path,
            "TAD_DOCKER_PYTEST_TARGET": "tests/test_kali_package_integration.py",
        },
        workspace_dir=tmp_path,
    )

    plan = plan_real_docker_bdd(config)

    assert config.base_image == "kalilinux/kali-rolling"
    assert "apt-get update" in plan.compose_yaml
    assert f"dpkg -i /workspace/{deb_path}" in plan.compose_yaml
    assert "python3-pytest" in plan.compose_yaml
    assert "tether-autolaunchd print-env >/tmp/tether-autolaunchd.env" in plan.compose_yaml


def test_install_deb_mode_requires_deb_path(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="TAD_DOCKER_DEB_PATH"):
        load_docker_integration_config(
            env={
                "TAD_DOCKER_MOCK": "false",
                "TAD_DOCKER_INSTALL_DEB": "true",
                "TAD_DOCKER_TETHER_IMAGE": "ghcr.io/example/tether:test",
            },
            workspace_dir=tmp_path,
        )


def test_fake_tether_fixture_does_not_require_live_tether_image(tmp_path: Path) -> None:
    config = load_docker_integration_config(
        env={
            "TAD_DOCKER_MOCK": "false",
            "TAD_DOCKER_FAKE_TETHER": "true",
            "TAD_DOCKER_INSTALL_DEB": "true",
            "TAD_DOCKER_DEB_PATH": _package_deb_path(),
        },
        workspace_dir=tmp_path,
    )

    plan = plan_real_docker_bdd(config)

    assert config.fake_tether is True
    assert config.tether_image is None
    assert "TAD_TETHER_BIN: /workspace/tests/fixtures/fake_tether_cli.py" in plan.compose_yaml
    assert 'TAD_START_TETHER: "false"' in plan.compose_yaml
    assert "TAD_FAKE_TETHER_SYNC_LOG: /tmp/tad-sync-log.jsonl" in plan.compose_yaml


def test_kali_deb_install_and_cli_smoke() -> None:
    if shutil.which("docker") is None:
        pytest.skip("docker is required for the Kali package smoke test")

    root = _repo_root()
    subprocess.run(["make", "build-deb"], cwd=root, check=True)
    env = dict(os.environ)
    env.update(
        {
            "TAD_DOCKER_MOCK": "false",
            "TAD_DOCKER_REAL": "true",
            "TAD_DOCKER_FAKE_TETHER": "true",
            "TAD_DOCKER_INSTALL_DEB": "true",
            "TAD_DOCKER_DEB_PATH": _package_deb_path(),
            "TAD_DOCKER_BASE_IMAGE": "kalilinux/kali-rolling",
            "TAD_DOCKER_PYTEST_TARGET": "tests/test_kali_package_cli_behaviors.py",
        }
    )
    subprocess.run(
        [".venv/bin/python", "scripts/run_docker_bdd.py"],
        cwd=root,
        env=env,
        check=True,
    )
