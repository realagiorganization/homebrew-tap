from __future__ import annotations

from pathlib import Path

from tether_autolaunchd.config import load_config


def test_load_config_uses_environment(tmp_path: Path) -> None:
    config = load_config(
        env={
            "TAD_TETHER_BIN": "/tmp/tether",
            "TAD_STATE_DIR": str(tmp_path / "state"),
            "TAD_POLL_SECONDS": "15",
            "TAD_TETHER_HOST": "0.0.0.0",
            "TAD_TETHER_PORT": "9123",
            "TAD_TETHER_DEV": "true",
            "TAD_START_TETHER": "false",
            "TAD_PLATFORM": "telegram",
            "TAD_RUNNER_TYPES": "codex,opencode",
        },
        env_file_paths=(),
    )

    assert config.tether_bin == "/tmp/tether"
    assert config.state_dir == tmp_path / "state"
    assert config.poll_seconds == 15
    assert config.command_timeout_seconds == 60
    assert config.tether_host == "0.0.0.0"
    assert config.tether_port == 9123
    assert config.tether_dev is True
    assert config.start_tether is False
    assert config.platform_mode == "fixed"
    assert config.platform == "telegram"
    assert config.runner_types == ("codex", "opencode")


def test_load_config_reads_command_timeout_override(tmp_path: Path) -> None:
    config = load_config(
        env={
            "TAD_STATE_DIR": str(tmp_path / "state"),
            "TAD_COMMAND_TIMEOUT_SECONDS": "90",
        },
        env_file_paths=(),
    )

    assert config.command_timeout_seconds == 90


def test_load_config_enables_discord_pairing_automation_when_requested(tmp_path: Path) -> None:
    config = load_config(
        env={
            "TAD_STATE_DIR": str(tmp_path / "state"),
            "DISCORD_BOT_TOKEN": "bot-token",
            "DISCORD_REQUIRE_PAIRING": "true",
            "TAD_DISCORD_PAIRING_AUTOMATION_TOKEN": "user-token",
        },
        env_file_paths=(),
    )

    assert config.discord_require_pairing is True
    assert config.discord_pairing_automation_enabled is True
    assert config.discord_pairing_automation_token == "user-token"
    assert config.discord_pairing_resources_reply == "yes"


def test_load_config_rejects_pairing_automation_without_pairing_enabled(tmp_path: Path) -> None:
    try:
        load_config(
            env={
                "TAD_STATE_DIR": str(tmp_path / "state"),
                "DISCORD_BOT_TOKEN": "bot-token",
                "TAD_DISCORD_PAIRING_AUTOMATION": "true",
                "TAD_DISCORD_PAIRING_AUTOMATION_TOKEN": "user-token",
            },
            env_file_paths=(),
        )
    except ValueError as exc:
        assert "DISCORD_REQUIRE_PAIRING" in str(exc)
    else:
        raise AssertionError("Expected pairing automation validation to fail")


def test_load_config_reads_env_files_with_process_env_precedence(tmp_path: Path) -> None:
    home_env = tmp_path / ".env"
    home_env.write_text("DISCORD_TOKEN=from-home\nTAD_PLATFORM_MODE=auto\n", encoding="utf-8")
    app_env = tmp_path / "config.env"
    app_env.write_text("SLACK_BOT_TOKEN=from-app\nDISCORD_TOKEN=from-app\n", encoding="utf-8")

    config = load_config(
        env={
            "DISCORD_TOKEN": "from-process",
            "TAD_STATE_DIR": str(tmp_path / "state"),
        },
        env_file_paths=(home_env, app_env),
    )

    assert config.available_platforms == ("discord", "slack")
    assert config.platform_mode == "auto"
    assert config.env_files == (home_env, app_env)


def test_load_config_detects_tether_style_discord_credentials(tmp_path: Path) -> None:
    env_file = tmp_path / ".env"
    env_file.write_text(
        "DISCORD_BOT_TOKEN=bot-token\nDISCORD_CHANNEL_ID=123456789\n",
        encoding="utf-8",
    )

    config = load_config(
        env={"TAD_STATE_DIR": str(tmp_path / "state")},
        env_file_paths=(env_file,),
    )

    assert config.available_platforms == ("discord",)


def test_load_config_detects_machine_channel_bootstrap_credentials(tmp_path: Path) -> None:
    env_file = tmp_path / ".env"
    env_file.write_text(
        "DISCORD_BOT_TOKEN=bot-token\nDISCORD_GUILD_ID=987654321\n",
        encoding="utf-8",
    )

    config = load_config(
        env={"TAD_STATE_DIR": str(tmp_path / "state")},
        env_file_paths=(env_file,),
    )

    assert config.available_platforms == ("discord",)
    assert config.discord_machine_channel_create is True


def test_load_config_can_disable_machine_channel_bootstrap(tmp_path: Path) -> None:
    env_file = tmp_path / ".env"
    env_file.write_text(
        "\n".join(
            [
                "DISCORD_BOT_TOKEN=bot-token",
                "DISCORD_GUILD_ID=987654321",
                "TAD_DISCORD_MACHINE_CHANNEL_CREATE=false",
            ]
        ),
        encoding="utf-8",
    )

    config = load_config(
        env={"TAD_STATE_DIR": str(tmp_path / "state")},
        env_file_paths=(env_file,),
    )

    assert config.available_platforms == ()
    assert config.discord_machine_channel_create is False


def test_load_config_reads_tad_env_files_from_bootstrap_config(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    bootstrap_config = tmp_path / ".config" / "tether-autolaunchd" / "config.env"
    custom_env = tmp_path / ".secrets.env"
    bootstrap_config.parent.mkdir(parents=True, exist_ok=True)
    custom_env.write_text(
        "DISCORD_BOT_TOKEN=bot-token\nDISCORD_CHANNEL_ID=123456789\n",
        encoding="utf-8",
    )
    bootstrap_config.write_text(f"TAD_ENV_FILES={custom_env}\n", encoding="utf-8")

    config = load_config(env={"TAD_STATE_DIR": str(tmp_path / "state")})

    assert config.env_files == (custom_env,)
    assert config.available_platforms == ("discord",)


def test_load_config_skips_invalid_env_lines(tmp_path: Path) -> None:
    env_file = tmp_path / ".env"
    env_file.write_text(
        "\n".join(
            [
                "export DISCORD_TOKEN=abc",
                "NOT_A_PAIR",
                "=missing_key",
                "TAD_PLATFORM_PREFERENCE=discord,slack",
            ]
        ),
        encoding="utf-8",
    )

    config = load_config(
        env={"TAD_STATE_DIR": str(tmp_path / "state")},
        env_file_paths=(env_file,),
    )

    assert config.available_platforms == ("discord",)
    assert config.platform_preference == ("discord", "slack")


def test_load_config_rejects_invalid_bool(monkeypatch) -> None:
    monkeypatch.setenv("TAD_START_TETHER", "maybe")
    try:
        load_config(env_file_paths=())
    except ValueError as exc:
        assert "TAD_START_TETHER" in str(exc)
    else:
        raise AssertionError("Expected invalid boolean to fail")


def test_load_config_rejects_invalid_platform_preference(tmp_path: Path) -> None:
    try:
        load_config(
            env={
                "TAD_STATE_DIR": str(tmp_path / "state"),
                "TAD_PLATFORM_PREFERENCE": "discord,telegram",
            },
            env_file_paths=(),
        )
    except ValueError as exc:
        assert "TAD_PLATFORM_PREFERENCE" in str(exc)
    else:
        raise AssertionError("Expected invalid platform preference to fail")


def test_load_config_rejects_missing_guild_for_machine_channel(tmp_path: Path) -> None:
    try:
        load_config(
            env={
                "TAD_STATE_DIR": str(tmp_path / "state"),
                "DISCORD_BOT_TOKEN": "bot-token",
                "TAD_DISCORD_MACHINE_CHANNEL_CREATE": "true",
            },
            env_file_paths=(),
        )
    except ValueError as exc:
        assert "DISCORD_GUILD_ID" in str(exc)
    else:
        raise AssertionError("Expected missing guild id to fail")
