from __future__ import annotations

import argparse
import json
import time
from collections.abc import Sequence

from .config import load_config
from .runtime import load_status_snapshot, render_env_example, render_user_service, run_once


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="tether-autolaunchd")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("once", help="Run a single discovery and auto-attach pass")
    daemon = subparsers.add_parser("daemon", help="Run the polling daemon")
    daemon.add_argument("--iterations", type=int, default=None, help=argparse.SUPPRESS)
    subparsers.add_parser("print-user-unit", help="Print the systemd user service unit")
    subparsers.add_parser("print-env", help="Print an example environment file")
    subparsers.add_parser("print-status-json", help="Print the last status snapshot as JSON")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)

    if args.command == "print-user-unit":
        config = load_config()
        print(render_user_service(config), end="")
        return 0
    if args.command == "print-env":
        load_config()
        print(render_env_example(), end="")
        return 0
    if args.command == "print-status-json":
        config = load_config()
        print(json.dumps(load_status_snapshot(config), indent=2, sort_keys=True))
        return 0
    if args.command == "once":
        config = load_config()
        summary = run_once(config)
        print(
            json.dumps(
                {
                    "attached_ids": list(summary.attached_ids),
                    "discovered_ids": list(summary.discovered_ids),
                    "failed_ids": list(summary.failed_ids),
                    "resolved_platform": summary.resolved_platform,
                    "runner_failures": {runner: error for runner, error in summary.runner_failures},
                    "skipped_ids": list(summary.skipped_ids),
                    "started_tether": summary.started_tether,
                    "synced_ids": list(summary.synced_ids),
                    "tether_healthy": summary.tether_healthy,
                },
                indent=2,
            )
        )
        return 0

    iterations = args.iterations
    count = 0
    while iterations is None or count < iterations:
        config = load_config()
        summary = run_once(config)
        print(
            json.dumps(
                {
                    "attached_count": len(summary.attached_ids),
                    "discovered_count": len(summary.discovered_ids),
                    "failed_count": len(summary.failed_ids),
                    "resolved_platform": summary.resolved_platform,
                    "runner_failure_count": len(summary.runner_failures),
                    "skipped_count": len(summary.skipped_ids),
                    "started_tether": summary.started_tether,
                    "synced_count": len(summary.synced_ids),
                    "tether_healthy": summary.tether_healthy,
                }
            )
        )
        count += 1
        if iterations is None or count < iterations:
            time.sleep(config.poll_seconds)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
