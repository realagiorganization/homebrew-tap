from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from collections.abc import Callable, Sequence
from dataclasses import dataclass, replace
from pathlib import Path

from .config import AppConfig
from .discord_machine_channel import DiscordMachineChannelResult, ensure_machine_channel
from .discord_pairing import (
    automate_pairing_from_local_log,
    load_pairing_automation_state,
)

CommandRunner = Callable[[Sequence[str]], subprocess.CompletedProcess[str]]
BackgroundStarter = Callable[[Sequence[str], Path], None]
_APPLIED_ENV_KEYS: set[str] = set()
FAILURE_COUNTER_KEYS = (
    "passes",
    "tether_start_attempts",
    "tether_start_suppressed_port_busy",
    "tether_start_disabled",
    "tether_unhealthy_passes",
    "runner_list_failures",
    "attach_succeeded",
    "attach_failed",
    "sync_succeeded",
    "sync_failed",
    "skipped_already_attached",
)
_TETHER_DISCORD_BRIDGE_PATCH_MARKER = "Multi-line `!new` requests start via reaction here."
_TETHER_DISCORD_BRIDGE_OLD_SNIPPET = (
    '            ) and self._should_defer_new_message_to_reaction(text):\n'
    "                return\n"
)
_TETHER_DISCORD_BRIDGE_NEW_SNIPPET = (
    '            ) and self._should_defer_new_message_to_reaction(text):\n'
    "                await message.channel.send(\n"
    '                    "ℹ️ Multi-line `!new` requests start via reaction here.\\n"\n'
    '                    f"React to your original message with '
    '{self._reaction_new_session_emoji} "\n'
    '                    "to create the session."\n'
    "                )\n"
    "                return\n"
)


@dataclass(frozen=True)
class ExternalSession:
    session_id: str
    runner_type: str


@dataclass(frozen=True)
class EnsureTetherResult:
    started: bool
    reason: str


@dataclass(frozen=True)
class RunSummary:
    started_tether: bool
    discovered_ids: tuple[str, ...]
    attached_ids: tuple[str, ...]
    synced_ids: tuple[str, ...] = ()
    tether_healthy: bool = False
    resolved_platform: str | None = None
    failed_ids: tuple[str, ...] = ()
    skipped_ids: tuple[str, ...] = ()
    runner_failures: tuple[tuple[str, str], ...] = ()


def _now_timestamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _stringify_error(exc: subprocess.SubprocessError | OSError) -> str:
    if isinstance(exc, subprocess.TimeoutExpired):
        timeout = int(exc.timeout) if isinstance(exc.timeout, (int, float)) else exc.timeout
        if timeout:
            return f"command timed out after {timeout}s"
        return "command timed out"
    if isinstance(exc, subprocess.CalledProcessError):
        if exc.stderr and exc.stderr.strip():
            return exc.stderr.strip().splitlines()[-1]
        if exc.stdout and exc.stdout.strip():
            return exc.stdout.strip().splitlines()[-1]
        return f"command exited with status {exc.returncode}"
    text = str(exc).strip()
    return text or exc.__class__.__name__


def parse_attached_session_id(output: str) -> str | None:
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line.lower().startswith("attached session "):
            continue
        session_id = line.split()[-1].strip()
        return session_id or None
    return None


def patch_tether_discord_bridge_source(source: str) -> tuple[str, str]:
    """Patch the known Discord reaction-shortcut silent-return bug.

    Returns the updated source plus a status string:
    ``patched``, ``already_patched``, or ``unsupported``.
    """
    if _TETHER_DISCORD_BRIDGE_PATCH_MARKER in source:
        return source, "already_patched"
    if _TETHER_DISCORD_BRIDGE_OLD_SNIPPET not in source:
        return source, "unsupported"
    return (
        source.replace(
            _TETHER_DISCORD_BRIDGE_OLD_SNIPPET,
            _TETHER_DISCORD_BRIDGE_NEW_SNIPPET,
            1,
        ),
        "patched",
    )


def resolve_tether_discord_bridge_path(tether_bin: str) -> Path | None:
    """Resolve the installed Tether Discord bridge source file from the CLI path."""
    raw_tether_bin = (tether_bin or "").strip()
    if not raw_tether_bin:
        return None

    if os.path.isabs(raw_tether_bin):
        tether_path = Path(raw_tether_bin).expanduser()
    else:
        resolved = shutil.which(raw_tether_bin)
        if not resolved:
            return None
        tether_path = Path(resolved)

    try:
        tether_path = tether_path.resolve(strict=True)
    except OSError:
        return None
    if tether_path.parent.name != "bin":
        return None

    site_packages = tether_path.parent.parent / "lib"
    matches = sorted(site_packages.glob("python*/site-packages/tether/bridges/discord/bot.py"))
    return matches[0] if matches else None


def ensure_tether_discord_bridge_feedback_patch(config: AppConfig) -> tuple[str, Path | None]:
    """Apply a known compatibility patch to the installed Tether Discord bridge."""
    bridge_path = resolve_tether_discord_bridge_path(config.tether_bin)
    if bridge_path is None:
        return "not_found", None

    try:
        source = bridge_path.read_text(encoding="utf-8")
    except OSError:
        return "read_failed", bridge_path

    patched_source, status = patch_tether_discord_bridge_source(source)
    if status != "patched":
        return status, bridge_path

    try:
        bridge_path.write_text(patched_source, encoding="utf-8")
    except OSError:
        return "write_failed", bridge_path
    return "patched", bridge_path


def _apply_tether_compat_patches(config: AppConfig) -> None:
    status, bridge_path = ensure_tether_discord_bridge_feedback_patch(config)
    if status == "patched":
        append_decision_log(
            config.decision_log_file,
            {
                "at": _now_timestamp(),
                "event": "tether_discord_bridge_patch_applied",
                "path": str(bridge_path),
            },
        )
        return
    if status in {"read_failed", "write_failed", "unsupported"}:
        append_decision_log(
            config.decision_log_file,
            {
                "at": _now_timestamp(),
                "event": "tether_discord_bridge_patch_skipped",
                "path": str(bridge_path) if bridge_path else None,
                "status": status,
            },
        )


def _default_failure_digest() -> dict[str, object]:
    return {
        "generated_at": None,
        "totals": {key: 0 for key in FAILURE_COUNTER_KEYS},
        "last_error_by_runner": {},
        "last_attach_failure": None,
    }


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _increment_total(digest: dict[str, object], key: str, amount: int = 1) -> None:
    totals = digest.setdefault("totals", {})
    assert isinstance(totals, dict)
    totals[key] = int(totals.get(key, 0)) + amount


def _read_digest_payload(path: Path) -> dict[str, object] | None:
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None


def _sanitize_last_error_by_runner(payload: object) -> dict[str, dict[str, str]]:
    if not isinstance(payload, dict):
        return {}
    sanitized: dict[str, dict[str, str]] = {}
    for runner, entry in payload.items():
        if not isinstance(entry, dict):
            continue
        sanitized[str(runner)] = {
            "at": str(entry.get("at", "")),
            "error": str(entry.get("error", "")),
        }
    return sanitized


def load_failure_digest(path: Path) -> dict[str, object]:
    digest = _default_failure_digest()
    payload = _read_digest_payload(path)
    if payload is None:
        return digest

    totals = payload.get("totals")
    if isinstance(totals, dict):
        for key in FAILURE_COUNTER_KEYS:
            value = totals.get(key)
            if isinstance(value, int):
                digest["totals"][key] = value

    digest["last_error_by_runner"] = _sanitize_last_error_by_runner(
        payload.get("last_error_by_runner")
    )

    last_attach_failure = payload.get("last_attach_failure")
    if isinstance(last_attach_failure, dict):
        digest["last_attach_failure"] = last_attach_failure

    generated_at = payload.get("generated_at")
    if isinstance(generated_at, str) or generated_at is None:
        digest["generated_at"] = generated_at
    return digest


def save_failure_digest(path: Path, digest: dict[str, object], generated_at: str) -> None:
    payload = {
        "generated_at": generated_at,
        "totals": dict(digest.get("totals", {})),
        "last_error_by_runner": dict(digest.get("last_error_by_runner", {})),
        "last_attach_failure": digest.get("last_attach_failure"),
    }
    _write_json(path, payload)


def append_decision_log(path: Path, event: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, sort_keys=True) + "\n")


def load_status_snapshot(config: AppConfig) -> dict[str, object]:
    if config.status_snapshot_file.exists():
        try:
            payload = json.loads(config.status_snapshot_file.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            payload = None
        if isinstance(payload, dict):
            payload.setdefault("tether_discord_pairing", _tether_discord_pairing_status(config))
            return payload
    return {
        "generated_at": None,
        "state_dir": str(config.state_dir),
        "decision_log_file": str(config.decision_log_file),
        "failure_digest_file": str(config.failure_digest_file),
        "status_snapshot_file": str(config.status_snapshot_file),
        "session_state_file": str(config.session_state_file),
        "seen_sessions_file": str(config.seen_sessions_file),
        "available_platforms": list(config.available_platforms),
        "resolved_platform": None,
        "runner_types": list(config.runner_types),
        "env_files": [str(path) for path in config.env_files],
        "discord_pairing_automation": {
            "enabled": config.discord_pairing_automation_enabled,
            "last_pair_command_at": None,
            "last_resource_reply_at": None,
            "state_file": str(config.discord_pairing_state_file),
        },
        "tether_discord_pairing": _tether_discord_pairing_status(config),
        "tether": {
            "host": config.tether_host,
            "port": config.tether_port,
            "started_this_pass": False,
            "healthy": False,
        },
        "last_pass": None,
        "failure_digest": load_failure_digest(config.failure_digest_file),
    }


def write_status_snapshot(
    config: AppConfig,
    summary: RunSummary,
    failure_digest: dict[str, object],
    tracked_session_count: int,
    generated_at: str,
) -> None:
    pairing_state = load_pairing_automation_state(config.discord_pairing_state_file)
    payload = {
        "generated_at": generated_at,
        "state_dir": str(config.state_dir),
        "decision_log_file": str(config.decision_log_file),
        "failure_digest_file": str(config.failure_digest_file),
        "status_snapshot_file": str(config.status_snapshot_file),
        "session_state_file": str(config.session_state_file),
        "seen_sessions_file": str(config.seen_sessions_file),
        "available_platforms": list(config.available_platforms),
        "resolved_platform": summary.resolved_platform,
        "runner_types": list(config.runner_types),
        "env_files": [str(path) for path in config.env_files],
        "discord_pairing_automation": {
            "dm_channel_id": pairing_state.get("dm_channel_id"),
            "enabled": config.discord_pairing_automation_enabled,
            "last_pair_command_at": pairing_state.get("last_pair_command_at"),
            "last_resource_reply_at": pairing_state.get("last_resource_reply_at"),
            "state_file": str(config.discord_pairing_state_file),
        },
        "tether_discord_pairing": _tether_discord_pairing_status(config),
        "tether": {
            "host": config.tether_host,
            "port": config.tether_port,
            "started_this_pass": summary.started_tether,
            "healthy": summary.tether_healthy,
        },
        "last_pass": {
            "attached_count": len(summary.attached_ids),
            "attached_ids": list(summary.attached_ids),
            "discovered_count": len(summary.discovered_ids),
            "discovered_ids": list(summary.discovered_ids),
            "failed_count": len(summary.failed_ids),
            "failed_ids": list(summary.failed_ids),
            "runner_failure_count": len(summary.runner_failures),
            "runner_failures": {runner: error for runner, error in summary.runner_failures},
            "skipped_count": len(summary.skipped_ids),
            "skipped_ids": list(summary.skipped_ids),
            "synced_count": len(summary.synced_ids),
            "synced_ids": list(summary.synced_ids),
            "tracked_session_count": tracked_session_count,
        },
        "failure_digest": {
            "generated_at": generated_at,
            "totals": dict(failure_digest.get("totals", {})),
            "last_error_by_runner": dict(failure_digest.get("last_error_by_runner", {})),
            "last_attach_failure": failure_digest.get("last_attach_failure"),
        },
    }
    _write_json(config.status_snapshot_file, payload)


def _tether_discord_pairing_status(config: AppConfig) -> dict[str, object]:
    override = config.runtime_env.get("TAD_TETHER_DISCORD_PAIRING_STATE_FILE", "").strip()
    data_dir = config.runtime_env.get("TETHER_AGENT_DATA_DIR", "").strip()
    repo_state = Path("~/subprojects/tether/agent/data/discord_pairing.json").expanduser()
    state_file = (
        Path(override).expanduser()
        if override
        else Path(data_dir).expanduser() / "discord_pairing.json"
        if data_dir
        else repo_state
        if repo_state.exists()
        else Path("~/.local/share/tether/discord_pairing.json").expanduser()
    )
    configured_ids = sorted(
        raw.strip()
        for raw in config.runtime_env.get("DISCORD_AUTO_PAIR_USER_IDS", "").split(",")
        if raw.strip()
    )
    try:
        payload = json.loads(state_file.read_text(encoding="utf-8")) if state_file.exists() else {}
    except json.JSONDecodeError:
        payload = {}
    paired_ids = sorted(
        str(raw).strip() for raw in payload.get("paired_user_ids", []) if str(raw).strip()
    )
    configured_channel_id = (
        config.runtime_env.get("DISCORD_CHANNEL_ID", "").strip() or config.discord_channel_id or ""
    )
    control_channel_matches_config = None
    if payload.get("control_channel_id") and configured_channel_id:
        control_channel_matches_config = (
            str(payload.get("control_channel_id", "")).strip() == configured_channel_id
        )
    return {
        "auto_pair_matches_state": paired_ids == configured_ids if configured_ids else None,
        "configured_auto_pair_user_count": len(configured_ids),
        "control_channel_matches_config": control_channel_matches_config,
        "has_pairing_code": bool(payload.get("pairing_code")),
        "paired_user_count": len(paired_ids),
        "pairing_required": config.discord_require_pairing,
        "satisfied": (not config.discord_require_pairing) or bool(paired_ids),
        "state_file": str(state_file),
        "state_file_exists": state_file.exists(),
    }


def default_runner(
    args: Sequence[str],
    *,
    timeout_seconds: int | None = None,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        check=True,
        text=True,
        capture_output=True,
        timeout=timeout_seconds,
    )


def _run_command(
    config: AppConfig,
    args: Sequence[str],
    *,
    runner: CommandRunner = default_runner,
) -> subprocess.CompletedProcess[str]:
    if runner is default_runner:
        return default_runner(args, timeout_seconds=config.command_timeout_seconds)
    return runner(args)


def default_background_starter(args: Sequence[str], log_file: Path) -> None:
    log_file.parent.mkdir(parents=True, exist_ok=True)
    with log_file.open("a", encoding="utf-8") as handle:
        subprocess.Popen(
            list(args),
            stdout=handle,
            stderr=handle,
            stdin=subprocess.DEVNULL,
        )


def apply_runtime_env(config: AppConfig) -> None:
    global _APPLIED_ENV_KEYS
    current_keys = set(config.runtime_env)
    for key in _APPLIED_ENV_KEYS - current_keys:
        os.environ.pop(key, None)
    for key, value in config.runtime_env.items():
        os.environ[key] = value
    _APPLIED_ENV_KEYS = current_keys


def _run_discord_pairing_automation(config: AppConfig) -> None:
    if not config.discord_pairing_automation_enabled:
        return
    try:
        result = automate_pairing_from_local_log(
            bot_token=config.discord_bot_token or "",
            automation_token=config.discord_pairing_automation_token or "",
            pairing_log_path=config.discord_pairing_log_path,
            state_path=config.discord_pairing_state_file,
            explicit_pairing_code=config.discord_pairing_code,
            resource_prompt_regex=config.discord_pairing_resources_prompt_regex,
            resource_reply=config.discord_pairing_resources_reply,
            now_timestamp=_now_timestamp,
        )
    except RuntimeError as exc:
        append_decision_log(
            config.decision_log_file,
            {
                "at": _now_timestamp(),
                "error": str(exc),
                "event": "discord_pairing_automation_failed",
            },
        )
        return

    if result.pair_command_sent:
        append_decision_log(
            config.decision_log_file,
            {
                "at": _now_timestamp(),
                "dm_channel_id": result.dm_channel_id,
                "event": "discord_pairing_command_sent",
            },
        )
    if result.resource_reply_sent:
        append_decision_log(
            config.decision_log_file,
            {
                "at": _now_timestamp(),
                "dm_channel_id": result.dm_channel_id,
                "event": "discord_pairing_resources_reply_sent",
                "reply": config.discord_pairing_resources_reply,
            },
        )


def _prepare_runtime_config(
    config: AppConfig,
) -> tuple[AppConfig, DiscordMachineChannelResult | None]:
    runtime_env = dict(config.runtime_env)
    if config.discord_bot_token:
        runtime_env.setdefault("DISCORD_BOT_TOKEN", config.discord_bot_token)
    if config.discord_channel_id and not config.discord_machine_channel_create:
        runtime_env.setdefault("DISCORD_CHANNEL_ID", config.discord_channel_id)

    channel_result = None
    if config.discord_machine_channel_create:
        channel_result = ensure_machine_channel(
            bot_token=config.discord_bot_token or "",
            guild_id=config.discord_guild_id or "",
            machine_name=config.discord_machine_name,
            prefix=config.discord_machine_channel_prefix,
            category_id=config.discord_machine_channel_category_id,
        )
        runtime_env["DISCORD_CHANNEL_ID"] = channel_result.channel_id

    if _should_default_to_opencode(runtime_env):
        runtime_env["TETHER_DEFAULT_AGENT_ADAPTER"] = "opencode"

    if not runtime_env.get("TETHER_CODEX_SIDECAR_CODEX_BIN", "").strip():
        codex_bin = _resolve_codex_cli_bin(runtime_env)
        if codex_bin:
            runtime_env["TETHER_CODEX_SIDECAR_CODEX_BIN"] = codex_bin

    if runtime_env == config.runtime_env:
        return config, channel_result
    return replace(config, runtime_env=runtime_env), channel_result


def _should_default_to_opencode(runtime_env: dict[str, str]) -> bool:
    if runtime_env.get("TETHER_DEFAULT_AGENT_ADAPTER", "").strip():
        return False
    if runtime_env.get("TETHER_AGENT_ADAPTER", "").strip():
        return False
    return _is_android_termux_runtime(runtime_env)


def _is_android_termux_runtime(runtime_env: dict[str, str]) -> bool:
    if runtime_env.get("TERMUX_VERSION", "").strip():
        return True
    prefix = runtime_env.get("PREFIX", "").strip()
    if "com.termux" in prefix:
        return True
    return bool(
        runtime_env.get("ANDROID_ROOT", "").strip()
        and runtime_env.get("ANDROID_DATA", "").strip()
    )


def _resolve_codex_cli_bin(runtime_env: dict[str, str]) -> str | None:
    configured_path = runtime_env.get("PATH", "").strip()
    if configured_path:
        resolved = shutil.which("codex", path=configured_path)
        if resolved:
            return resolved

    home = runtime_env.get("HOME", "").strip()
    if home:
        for candidate in (
            Path(home) / ".local" / "bin" / "codex",
            Path(home) / "bin" / "codex",
        ):
            if candidate.is_file() and os.access(candidate, os.X_OK):
                return str(candidate)

    ambient_path = os.environ.get("PATH", "")
    if ambient_path:
        return shutil.which("codex", path=ambient_path)
    return shutil.which("codex")


def _prepare_runtime_config_or_log(config: AppConfig) -> AppConfig:
    try:
        prepared_config, discord_channel_result = _prepare_runtime_config(config)
    except RuntimeError as exc:
        append_decision_log(
            config.decision_log_file,
            {
                "at": _now_timestamp(),
                "error": str(exc),
                "event": "discord_machine_channel_failed",
                "guild_id": config.discord_guild_id,
                "machine_name": config.discord_machine_name,
            },
        )
        return config

    if discord_channel_result is not None:
        append_decision_log(
            prepared_config.decision_log_file,
            {
                "at": _now_timestamp(),
                "channel_id": discord_channel_result.channel_id,
                "channel_name": discord_channel_result.channel_name,
                "created": discord_channel_result.created,
                "event": "discord_machine_channel_ready",
                "guild_id": prepared_config.discord_guild_id,
                "machine_name": prepared_config.discord_machine_name,
            },
        )
    return prepared_config


def healthcheck(config: AppConfig) -> bool:
    url = f"http://{config.tether_host}:{config.tether_port}/api/health"
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    request = urllib.request.Request(url)
    try:
        with opener.open(request, timeout=2) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        if config.start_tether:
            return False
        try:
            result = subprocess.run(
                [config.tether_bin, "health"],
                check=True,
                text=True,
                capture_output=True,
                timeout=min(config.command_timeout_seconds, 5),
            )
        except (subprocess.SubprocessError, OSError):
            return False
        output = (result.stdout or "").strip()
        if not output:
            return True
        try:
            payload = json.loads(output)
        except json.JSONDecodeError:
            return True
        return bool(payload.get("ok"))
    return bool(payload.get("ok"))


def is_tether_port_open(config: AppConfig) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.5)
        return sock.connect_ex((config.tether_host, config.tether_port)) == 0


def build_tether_start_command(config: AppConfig) -> list[str]:
    command = [
        config.tether_bin,
        "start",
        "--host",
        config.tether_host,
        "--port",
        str(config.tether_port),
    ]
    if config.tether_dev:
        command.append("--dev")
    return command


def render_user_service(
    config: AppConfig,
    *,
    exec_start: str | None = None,
) -> str:
    home_prefix = f"{Path.home()}/"

    env_paths: list[str] = []
    seen_paths: set[str] = set()
    for path in (*config.env_files, config.config_env_path):
        raw_path = str(path)
        if raw_path == str(Path.home()):
            raw_path = "%h"
        elif raw_path.startswith(home_prefix):
            raw_path = f"%h/{raw_path.removeprefix(home_prefix)}"
        if raw_path in seen_paths:
            continue
        seen_paths.add(raw_path)
        env_paths.append(raw_path)
    env_lines = "".join(f"EnvironmentFile=-{path}\n" for path in env_paths)
    resolved_exec_start = exec_start or f"{sys.executable} -m tether_autolaunchd.cli daemon"
    return (
        "[Unit]\n"
        "Description=Tether autolaunch daemon\n"
        "After=network-online.target\n\n"
        "[Service]\n"
        "Type=simple\n"
        "WorkingDirectory=%h\n"
        f"{env_lines}"
        f"ExecStart={resolved_exec_start}\n"
        "Restart=always\n"
        "RestartSec=5\n\n"
        "[Install]\n"
        "WantedBy=default.target\n"
    )


def render_env_example() -> str:
    return (
        "TAD_TETHER_BIN=tether\n"
        "TAD_TETHER_HOST=127.0.0.1\n"
        "TAD_TETHER_PORT=8787\n"
        "TAD_TETHER_DEV=true\n"
        "TAD_START_TETHER=true\n"
        "TAD_PLATFORM_MODE=auto\n"
        "TAD_PLATFORM=discord\n"
        "TAD_PLATFORM_PREFERENCE=discord,slack\n"
        "TAD_RUNNER_TYPES=codex,claude,opencode,pi\n"
        "# On Android/Termux, leave the adapter unset here and the launcher\n"
        "# will inject TETHER_DEFAULT_AGENT_ADAPTER=opencode when needed.\n"
        "# TETHER_DEFAULT_AGENT_ADAPTER=opencode\n"
        "TAD_COMMAND_TIMEOUT_SECONDS=60\n"
        "TAD_ENV_FILES=~/.env,~/.ENV,~/.config/tether/config.env,~/subprojects/tether/.env,~/subprojects/tether/.ENV,~/.config/tether-autolaunchd/config.env\n"
        "TAD_DISCORD_MACHINE_CHANNEL_CREATE=true\n"
        "TAD_DISCORD_MACHINE_CHANNEL_PREFIX=🖥️\n"
        "TAD_DISCORD_MACHINE_NAME=\n"
        "TAD_DISCORD_MACHINE_CHANNEL_CATEGORY_ID=\n"
        "TAD_DISCORD_PAIRING_AUTOMATION=false\n"
        "TAD_DISCORD_PAIRING_AUTOMATION_TOKEN=\n"
        "TAD_DISCORD_PAIRING_LOG_PATH=\n"
        "TAD_DISCORD_PAIRING_RESOURCES_PROMPT_REGEX=(?i)resources.*maintaining this session\n"
        "TAD_DISCORD_PAIRING_RESOURCES_REPLY=yes\n"
        "DISCORD_TOKEN=\n"
        "DISCORD_BOT_TOKEN=\n"
        "DISCORD_GUILD_ID=\n"
        "DISCORD_CHANNEL_ID=\n"
        "DISCORD_REQUIRE_PAIRING=false\n"
        "DISCORD_PAIRING_CODE=\n"
        "SLACK_BOT_TOKEN=\n"
        "TAD_POLL_SECONDS=10\n"
    )


def parse_external_session_ids(output: str) -> tuple[str, ...]:
    ids: list[str] = []
    for raw_line in output.splitlines():
        line = raw_line.strip()
        lowered = line.lower()
        if not line or lowered.startswith("usage:") or lowered.startswith("no "):
            continue
        if line.startswith("ID ") or line.startswith("ID\t"):
            continue
        if set(line) <= {"-", "─", " "}:
            continue
        token = line.split()[0]
        if token.lower() == "id":
            continue
        ids.append(token)
    return tuple(ids)


def load_seen_ids(path: Path) -> set[str]:
    if not path.exists():
        return set()
    return {line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()}


def save_seen_ids(path: Path, ids: set[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(sorted(ids)) + ("\n" if ids else ""), encoding="utf-8")


def resolve_platform(config: AppConfig) -> str | None:
    if config.platform_mode == "off":
        return None
    if config.platform_mode == "fixed":
        return config.platform
    for platform in config.platform_preference:
        if platform in config.available_platforms:
            return platform
    return None


def load_session_state(
    path: Path,
    legacy_seen_file: Path | None = None,
) -> dict[str, dict[str, object]]:
    if path.exists():
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            payload = {}
        sessions = payload.get("sessions")
        if isinstance(sessions, dict):
            return {
                str(session_id): record
                for session_id, record in sessions.items()
                if isinstance(record, dict)
            }
    if legacy_seen_file is None:
        return {}
    migrated_ids = load_seen_ids(legacy_seen_file)
    return {
        session_id: {
            "attached_platform": None,
            "attach_status": "attached",
            "first_seen_at": None,
            "last_attempt_at": None,
            "runner_type": None,
        }
        for session_id in migrated_ids
    }


def save_session_state(path: Path, sessions: dict[str, dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"sessions": {session_id: sessions[session_id] for session_id in sorted(sessions)}}
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def should_attach_session(record: dict[str, object] | None, platform: str | None) -> bool:
    if record is None:
        return True
    if record.get("attach_status") != "attached":
        return True
    return record.get("attached_platform") != platform


def attach_reason(record: dict[str, object] | None, platform: str | None) -> str:
    if record is None:
        return "new_session"
    if record.get("attach_status") != "attached":
        return "retry_failed_attachment"
    if record.get("attached_platform") != platform:
        return "platform_changed"
    return "already_attached"


def ensure_tether_running(
    config: AppConfig,
    is_healthy: Callable[[AppConfig], bool] = healthcheck,
    background_starter: BackgroundStarter = default_background_starter,
    sleeper: Callable[[float], None] = time.sleep,
) -> EnsureTetherResult:
    if is_healthy(config):
        return EnsureTetherResult(False, "already_healthy")
    if is_tether_port_open(config):
        return EnsureTetherResult(False, "port_busy")
    if not config.start_tether:
        return EnsureTetherResult(False, "disabled")
    background_starter(build_tether_start_command(config), config.log_file)
    for _ in range(10):
        if is_healthy(config):
            return EnsureTetherResult(True, "started")
        sleeper(0.2)
    return EnsureTetherResult(True, "started_unhealthy")


def list_external_sessions(
    config: AppConfig,
    runner: CommandRunner = default_runner,
) -> tuple[tuple[ExternalSession, ...], tuple[tuple[str, str], ...]]:
    discovered: list[ExternalSession] = []
    runner_failures: list[tuple[str, str]] = []
    for runner_type in config.runner_types:
        try:
            result = _run_command(
                config,
                [config.tether_bin, "list", "--external", "-r", runner_type],
                runner=runner,
            )
        except (subprocess.SubprocessError, OSError) as exc:
            runner_failures.append((runner_type, _stringify_error(exc)))
            continue
        for session_id in parse_external_session_ids(result.stdout):
            discovered.append(ExternalSession(session_id=session_id, runner_type=runner_type))
    unique: list[ExternalSession] = []
    seen: set[str] = set()
    for session in discovered:
        if session.session_id in seen:
            continue
        seen.add(session.session_id)
        unique.append(session)
    return tuple(unique), tuple(runner_failures)


def attach_session(
    session_id: str,
    config: AppConfig,
    platform: str | None = None,
    runner: CommandRunner = default_runner,
) -> str | None:
    command = [config.tether_bin, "attach", session_id]
    if platform:
        command.extend(["-p", platform])
    result = _run_command(config, command, runner=runner)
    return parse_attached_session_id(result.stdout)


def sync_session(
    tether_session_id: str,
    config: AppConfig,
    runner: CommandRunner = default_runner,
) -> None:
    _run_command(config, [config.tether_bin, "sync", tether_session_id], runner=runner)


def _record_startup_totals(digest: dict[str, object], startup_result: EnsureTetherResult) -> None:
    if startup_result.reason in {"started", "started_unhealthy"}:
        _increment_total(digest, "tether_start_attempts")
        return
    if startup_result.reason == "port_busy":
        _increment_total(digest, "tether_start_suppressed_port_busy")
        return
    if startup_result.reason == "disabled":
        _increment_total(digest, "tether_start_disabled")


def _finalize_pass(
    config: AppConfig,
    summary: RunSummary,
    digest: dict[str, object],
    tracked_session_count: int,
    tether_start_reason: str,
) -> RunSummary:
    generated_at = _now_timestamp()
    save_failure_digest(config.failure_digest_file, digest, generated_at)
    write_status_snapshot(
        config,
        summary,
        digest,
        tracked_session_count=tracked_session_count,
        generated_at=generated_at,
    )
    append_decision_log(
        config.decision_log_file,
        {
            "at": generated_at,
            "attached_count": len(summary.attached_ids),
            "discovered_count": len(summary.discovered_ids),
            "event": "pass_summary",
            "failed_count": len(summary.failed_ids),
            "resolved_platform": summary.resolved_platform,
            "runner_failure_count": len(summary.runner_failures),
            "skipped_count": len(summary.skipped_ids),
            "synced_count": len(summary.synced_ids),
            "tether_healthy": summary.tether_healthy,
            "tether_start_reason": tether_start_reason,
            "tracked_session_count": tracked_session_count,
        },
    )
    return summary


def _record_runner_failure(
    config: AppConfig,
    digest: dict[str, object],
    runner_type: str,
    error: str,
) -> None:
    timestamp = _now_timestamp()
    _increment_total(digest, "runner_list_failures")
    digest["last_error_by_runner"][runner_type] = {
        "at": timestamp,
        "error": error,
    }
    append_decision_log(
        config.decision_log_file,
        {
            "at": timestamp,
            "error": error,
            "event": "runner_scan_failed",
            "runner_type": runner_type,
        },
    )


def _handle_skipped_session(
    config: AppConfig,
    digest: dict[str, object],
    session: ExternalSession,
    platform: str | None,
    reason: str,
) -> None:
    _increment_total(digest, "skipped_already_attached")
    append_decision_log(
        config.decision_log_file,
        {
            "at": _now_timestamp(),
            "event": "session_attach_skipped",
            "platform": platform,
            "reason": reason,
            "runner_type": session.runner_type,
            "session_id": session.session_id,
        },
    )


def _handle_attach_failure(
    config: AppConfig,
    digest: dict[str, object],
    sessions: dict[str, dict[str, object]],
    session: ExternalSession,
    platform: str | None,
    reason: str,
    timestamp: str,
    error: str,
    first_seen_at: object,
) -> None:
    _increment_total(digest, "attach_failed")
    digest["last_error_by_runner"][session.runner_type] = {
        "at": timestamp,
        "error": error,
    }
    digest["last_attach_failure"] = {
        "at": timestamp,
        "error": error,
        "platform": platform,
        "reason": reason,
        "runner_type": session.runner_type,
        "session_id": session.session_id,
    }
    sessions[session.session_id] = {
        "attached_platform": platform,
        "attach_status": "failed",
        "first_seen_at": first_seen_at or timestamp,
        "last_attempt_at": timestamp,
        "runner_type": session.runner_type,
    }
    append_decision_log(
        config.decision_log_file,
        {
            "at": timestamp,
            "error": error,
            "event": "session_attach_failed",
            "platform": platform,
            "reason": reason,
            "runner_type": session.runner_type,
            "session_id": session.session_id,
        },
    )


def _handle_sync_success(
    config: AppConfig,
    digest: dict[str, object],
    sessions: dict[str, dict[str, object]],
    session: ExternalSession,
    platform: str | None,
    tether_session_id: str,
    timestamp: str,
) -> None:
    _increment_total(digest, "sync_succeeded")
    record = sessions.setdefault(session.session_id, {})
    record.update(
        {
            "attached_platform": platform,
            "attach_status": "attached",
            "last_attempt_at": timestamp,
            "last_synced_at": timestamp,
            "last_sync_error": None,
            "runner_type": session.runner_type,
            "tether_session_id": tether_session_id,
        }
    )
    append_decision_log(
        config.decision_log_file,
        {
            "at": timestamp,
            "event": "session_sync_succeeded",
            "platform": platform,
            "runner_type": session.runner_type,
            "session_id": session.session_id,
            "tether_session_id": tether_session_id,
        },
    )


def _handle_sync_failure(
    config: AppConfig,
    digest: dict[str, object],
    sessions: dict[str, dict[str, object]],
    session: ExternalSession,
    platform: str | None,
    tether_session_id: str,
    timestamp: str,
    error: str,
) -> None:
    _increment_total(digest, "sync_failed")
    record = sessions.setdefault(session.session_id, {})
    record.update(
        {
            "attached_platform": platform,
            "attach_status": "attached",
            "last_attempt_at": timestamp,
            "last_sync_error": error,
            "runner_type": session.runner_type,
            "tether_session_id": tether_session_id,
        }
    )
    digest["last_error_by_runner"][session.runner_type] = {
        "at": timestamp,
        "error": error,
    }
    append_decision_log(
        config.decision_log_file,
        {
            "at": timestamp,
            "error": error,
            "event": "session_sync_failed",
            "platform": platform,
            "runner_type": session.runner_type,
            "session_id": session.session_id,
            "tether_session_id": tether_session_id,
        },
    )


def _handle_attach_success(
    config: AppConfig,
    digest: dict[str, object],
    sessions: dict[str, dict[str, object]],
    session: ExternalSession,
    platform: str | None,
    reason: str,
    timestamp: str,
    first_seen_at: object,
    tether_session_id: str | None,
) -> None:
    _increment_total(digest, "attach_succeeded")
    sessions[session.session_id] = {
        "attached_platform": platform,
        "attach_status": "attached",
        "first_seen_at": first_seen_at or timestamp,
        "last_attempt_at": timestamp,
        "runner_type": session.runner_type,
        "tether_session_id": tether_session_id,
    }
    append_decision_log(
        config.decision_log_file,
        {
            "at": timestamp,
            "event": "session_attach_succeeded",
            "platform": platform,
            "reason": reason,
            "runner_type": session.runner_type,
            "session_id": session.session_id,
            "tether_session_id": tether_session_id,
        },
    )


def _attached_tether_session_id(record: dict[str, object] | None) -> str | None:
    if record is None:
        return None
    tether_session_id = str(record.get("tether_session_id", "")).strip()
    return tether_session_id or None


def _process_session(
    config: AppConfig,
    session: ExternalSession,
    sessions: dict[str, dict[str, object]],
    digest: dict[str, object],
    platform: str | None,
    runner: CommandRunner,
) -> str:
    record = sessions.get(session.session_id)
    reason = attach_reason(record, platform)
    first_seen_at = record.get("first_seen_at") if record else None

    if should_attach_session(record, platform):
        timestamp = _now_timestamp()
        try:
            tether_session_id = attach_session(
                session.session_id,
                config,
                platform=platform,
                runner=runner,
            )
        except (subprocess.SubprocessError, OSError) as exc:
            _handle_attach_failure(
                config,
                digest,
                sessions,
                session,
                platform,
                reason,
                timestamp,
                _stringify_error(exc),
                first_seen_at,
            )
            return "failed"

        _handle_attach_success(
            config,
            digest,
            sessions,
            session,
            platform,
            reason,
            timestamp,
            first_seen_at,
            tether_session_id,
        )
        return "attached"

    tether_session_id = _attached_tether_session_id(record)
    if tether_session_id is None:
        timestamp = _now_timestamp()
        try:
            tether_session_id = attach_session(
                session.session_id,
                config,
                platform=platform,
                runner=runner,
            )
        except (subprocess.SubprocessError, OSError) as exc:
            _handle_attach_failure(
                config,
                digest,
                sessions,
                session,
                platform,
                "sync_binding_missing",
                timestamp,
                _stringify_error(exc),
                first_seen_at,
            )
            return "failed"
        _handle_attach_success(
            config,
            digest,
            sessions,
            session,
            platform,
            "sync_binding_missing",
            timestamp,
            first_seen_at,
            tether_session_id,
        )

    if tether_session_id is None:
        _handle_skipped_session(config, digest, session, platform, "missing_tether_session_id")
        return "skipped"

    timestamp = _now_timestamp()
    try:
        sync_session(tether_session_id, config, runner=runner)
    except (subprocess.SubprocessError, OSError) as exc:
        _handle_sync_failure(
            config,
            digest,
            sessions,
            session,
            platform,
            tether_session_id,
            timestamp,
            _stringify_error(exc),
        )
        return "failed"

    _handle_sync_success(
        config,
        digest,
        sessions,
        session,
        platform,
        tether_session_id,
        timestamp,
    )
    return "synced"


def run_once(
    config: AppConfig,
    runner: CommandRunner = default_runner,
    is_healthy: Callable[[AppConfig], bool] = healthcheck,
    background_starter: BackgroundStarter = default_background_starter,
    sleeper: Callable[[float], None] = time.sleep,
) -> RunSummary:
    config = _prepare_runtime_config_or_log(config)
    apply_runtime_env(config)
    _apply_tether_compat_patches(config)
    digest = load_failure_digest(config.failure_digest_file)
    _increment_total(digest, "passes")
    startup_result = ensure_tether_running(
        config,
        is_healthy=is_healthy,
        background_starter=background_starter,
        sleeper=sleeper,
    )
    _record_startup_totals(digest, startup_result)

    resolved_platform = resolve_platform(config)
    tether_healthy = is_healthy(config)
    if not tether_healthy:
        _increment_total(digest, "tether_unhealthy_passes")
        summary = RunSummary(
            started_tether=startup_result.started,
            discovered_ids=(),
            attached_ids=(),
            tether_healthy=False,
            resolved_platform=resolved_platform,
        )
        return _finalize_pass(
            config,
            summary,
            digest,
            tracked_session_count=0,
            tether_start_reason=startup_result.reason,
        )

    _run_discord_pairing_automation(config)
    sessions = load_session_state(
        config.session_state_file,
        legacy_seen_file=config.seen_sessions_file,
    )
    discovered_sessions, runner_failures = list_external_sessions(config, runner=runner)
    attached: list[str] = []
    failed: list[str] = []
    skipped: list[str] = []
    synced: list[str] = []

    for runner_type, error in runner_failures:
        _record_runner_failure(config, digest, runner_type, error)

    for session in discovered_sessions:
        outcome = _process_session(
            config,
            session,
            sessions,
            digest,
            resolved_platform,
            runner,
        )
        if outcome == "attached":
            attached.append(session.session_id)
        elif outcome == "synced":
            synced.append(session.session_id)
        elif outcome == "failed":
            failed.append(session.session_id)
        else:
            skipped.append(session.session_id)

    save_session_state(config.session_state_file, sessions)
    save_seen_ids(
        config.seen_sessions_file,
        {
            session_id
            for session_id, record in sessions.items()
            if record.get("attach_status") == "attached"
        },
    )
    summary = RunSummary(
        started_tether=startup_result.started,
        discovered_ids=tuple(session.session_id for session in discovered_sessions),
        attached_ids=tuple(attached),
        synced_ids=tuple(synced),
        tether_healthy=True,
        resolved_platform=resolved_platform,
        failed_ids=tuple(failed),
        skipped_ids=tuple(skipped),
        runner_failures=runner_failures,
    )
    return _finalize_pass(
        config,
        summary,
        digest,
        tracked_session_count=len(sessions),
        tether_start_reason=startup_result.reason,
    )
