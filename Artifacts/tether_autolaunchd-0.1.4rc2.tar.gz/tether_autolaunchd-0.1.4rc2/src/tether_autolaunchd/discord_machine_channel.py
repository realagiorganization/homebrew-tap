from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass

DiscordRequest = Callable[[str, str, str, dict[str, object] | None], object]
_DISCORD_API_BASE = "https://discord.com/api/v10"
_MACHINE_SLUG_RE = re.compile(r"[^a-z0-9]+")


@dataclass(frozen=True)
class DiscordMachineChannelResult:
    channel_id: str
    channel_name: str
    created: bool


def slugify_machine_name(machine_name: str) -> str:
    slug = _MACHINE_SLUG_RE.sub("-", machine_name.strip().lower()).strip("-")
    return slug or "computer"


def build_machine_channel_name(machine_name: str, prefix: str = "🖥️") -> str:
    normalized_prefix = prefix.strip().rstrip("-") or "🖥️"
    return f"{normalized_prefix}-{slugify_machine_name(machine_name)}"


def _discord_request_json(
    method: str,
    path: str,
    bot_token: str,
    payload: dict[str, object] | None = None,
) -> object:
    headers = {
        "Authorization": f"Bot {bot_token}",
        "User-Agent": "tether-autolaunchd/0.1",
    }
    data = None
    if payload is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        f"{_DISCORD_API_BASE}{path}",
        data=data,
        headers=headers,
        method=method.upper(),
    )
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(request, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace").strip()
        message = f"Discord API {method.upper()} {path} failed with HTTP {exc.code}: {body[:200]}"
        raise RuntimeError(message) from exc
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Discord API {method.upper()} {path} failed: {exc}") from exc


def _matching_channel_id(
    channels: object,
    *,
    channel_name: str,
    category_id: str | None,
) -> str | None:
    if not isinstance(channels, list):
        raise RuntimeError("Discord API returned a non-list channel payload")

    expected_parent = str(category_id) if category_id else None
    for raw_channel in channels:
        if not isinstance(raw_channel, dict):
            continue
        if int(raw_channel.get("type", -1)) != 0:
            continue
        if str(raw_channel.get("name", "")) != channel_name:
            continue
        parent_id = raw_channel.get("parent_id")
        if expected_parent is not None and str(parent_id or "") != expected_parent:
            continue
        channel_id = str(raw_channel.get("id", "")).strip()
        if channel_id:
            return channel_id
    return None


def _build_create_channel_payload(
    *,
    channel_name: str,
    machine_name: str,
    category_id: str | None,
) -> dict[str, object]:
    payload: dict[str, object] = {
        "name": channel_name,
        "type": 0,
        "topic": f"Tether control channel for {machine_name}",
    }
    if category_id:
        payload["parent_id"] = str(category_id)
    return payload


def _create_channel(
    *,
    request_json: DiscordRequest,
    guild_id: str,
    bot_token: str,
    payload: dict[str, object],
) -> str:
    created_channel = request_json("POST", f"/guilds/{guild_id}/channels", bot_token, payload)
    if not isinstance(created_channel, dict):
        raise RuntimeError("Discord API returned a non-object create-channel payload")
    channel_id = str(created_channel.get("id", "")).strip()
    if not channel_id:
        raise RuntimeError("Discord API create-channel response did not include an id")
    return channel_id


def ensure_machine_channel(
    *,
    bot_token: str,
    guild_id: str,
    machine_name: str,
    prefix: str = "🖥️",
    category_id: str | None = None,
    request_json: DiscordRequest = _discord_request_json,
) -> DiscordMachineChannelResult:
    channel_name = build_machine_channel_name(machine_name=machine_name, prefix=prefix)
    channels = request_json("GET", f"/guilds/{guild_id}/channels", bot_token, None)
    existing_channel_id = _matching_channel_id(
        channels,
        channel_name=channel_name,
        category_id=category_id,
    )
    if existing_channel_id:
        return DiscordMachineChannelResult(
            channel_id=existing_channel_id,
            channel_name=channel_name,
            created=False,
        )

    payload = _build_create_channel_payload(
        channel_name=channel_name,
        machine_name=machine_name,
        category_id=category_id,
    )
    channel_id = _create_channel(
        request_json=request_json,
        guild_id=guild_id,
        bot_token=bot_token,
        payload=payload,
    )
    return DiscordMachineChannelResult(
        channel_id=channel_id,
        channel_name=channel_name,
        created=True,
    )
