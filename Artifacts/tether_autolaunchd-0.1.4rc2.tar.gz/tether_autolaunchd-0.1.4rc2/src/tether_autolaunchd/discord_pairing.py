from __future__ import annotations

import hashlib
import json
import re
import urllib.error
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

DiscordRequest = Callable[[str, str, str, dict[str, object] | None], object]
_DISCORD_API_BASE = "https://discord.com/api/v10"
_ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")
_PAIRING_CODE_RE = re.compile(
    r"Discord pairing enabled\. DM the bot: !pair <code>.*?\bcode=(?P<code>[^\s]+)"
)


@dataclass(frozen=True)
class DiscordPairingAutomationResult:
    pairing_code_found: bool
    pair_command_sent: bool = False
    resource_reply_sent: bool = False
    dm_channel_id: str | None = None
    bot_user_id: str | None = None


def _strip_ansi(text: str) -> str:
    return _ANSI_ESCAPE_RE.sub("", text)


def extract_latest_pairing_code(log_text: str) -> str | None:
    for raw_line in reversed(log_text.splitlines()):
        line = _strip_ansi(raw_line)
        match = _PAIRING_CODE_RE.search(line)
        if match:
            pairing_code = match.group("code").strip()
            if pairing_code:
                return pairing_code
    return None


def _discord_request_json(
    method: str,
    path: str,
    authorization: str,
    payload: dict[str, object] | None = None,
) -> object:
    headers = {
        "Authorization": authorization,
        "User-Agent": "tether-autolaunchd/0.1",
    }
    data = None
    if payload is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        f"{_DISCORD_API_BASE}{path}",
        data=data,
        headers=headers,
        method=method.upper(),
    )
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(request, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace").strip()
        message = f"Discord API {method.upper()} {path} failed with HTTP {exc.code}: {body[:200]}"
        raise RuntimeError(message) from exc
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Discord API {method.upper()} {path} failed: {exc}") from exc


def load_pairing_automation_state(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    if not isinstance(payload, dict):
        return {}
    state: dict[str, str] = {}
    for key in (
        "bot_user_id",
        "dm_channel_id",
        "last_pair_code_sha256",
        "last_pair_command_at",
        "last_pair_command_message_id",
        "last_resource_prompt_message_id",
        "last_resource_reply_at",
        "last_resource_reply_message_id",
    ):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            state[key] = value.strip()
    return state


def save_pairing_automation_state(path: Path, state: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {key: state[key] for key in sorted(state)}
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _pairing_code_sha256(pairing_code: str) -> str:
    return hashlib.sha256(pairing_code.encode("utf-8")).hexdigest()


def _fetch_bot_user_id(
    *,
    bot_token: str,
    request_json: DiscordRequest,
) -> str:
    payload = request_json("GET", "/users/@me", f"Bot {bot_token}", None)
    if not isinstance(payload, dict):
        raise RuntimeError("Discord API returned a non-object bot identity payload")
    bot_user_id = str(payload.get("id", "")).strip()
    if not bot_user_id:
        raise RuntimeError("Discord API bot identity response did not include an id")
    return bot_user_id


def _ensure_dm_channel(
    *,
    automation_token: str,
    bot_user_id: str,
    request_json: DiscordRequest,
) -> str:
    payload = request_json(
        "POST",
        "/users/@me/channels",
        automation_token,
        {"recipient_id": bot_user_id},
    )
    if not isinstance(payload, dict):
        raise RuntimeError("Discord API returned a non-object DM channel payload")
    channel_id = str(payload.get("id", "")).strip()
    if not channel_id:
        raise RuntimeError("Discord API DM channel response did not include an id")
    return channel_id


def _send_message(
    *,
    automation_token: str,
    channel_id: str,
    content: str,
    request_json: DiscordRequest,
) -> str:
    payload = request_json(
        "POST",
        f"/channels/{channel_id}/messages",
        automation_token,
        {"content": content},
    )
    if not isinstance(payload, dict):
        raise RuntimeError("Discord API returned a non-object message payload")
    message_id = str(payload.get("id", "")).strip()
    if not message_id:
        raise RuntimeError("Discord API message response did not include an id")
    return message_id


def _fetch_recent_messages(
    *,
    automation_token: str,
    channel_id: str,
    request_json: DiscordRequest,
    limit: int = 10,
) -> list[dict[str, object]]:
    payload = request_json(
        "GET",
        f"/channels/{channel_id}/messages?limit={limit}",
        automation_token,
        None,
    )
    if not isinstance(payload, list):
        raise RuntimeError("Discord API returned a non-list messages payload")
    return [message for message in payload if isinstance(message, dict)]


def _latest_resource_prompt_message_id(
    messages: list[dict[str, object]],
    *,
    bot_user_id: str,
    resource_prompt_regex: str,
) -> str | None:
    prompt_re = re.compile(resource_prompt_regex)
    for message in messages:
        author = message.get("author")
        if not isinstance(author, dict):
            continue
        if str(author.get("id", "")).strip() != bot_user_id:
            continue
        content = str(message.get("content", ""))
        if not prompt_re.search(content):
            continue
        message_id = str(message.get("id", "")).strip()
        if message_id:
            return message_id
    return None


def automate_pairing_from_local_log(
    *,
    bot_token: str,
    automation_token: str,
    pairing_log_path: Path,
    state_path: Path,
    explicit_pairing_code: str | None = None,
    resource_prompt_regex: str = r"(?i)resources.*maintaining this session",
    resource_reply: str = "yes",
    now_timestamp: Callable[[], str],
    request_json: DiscordRequest = _discord_request_json,
) -> DiscordPairingAutomationResult:
    state = load_pairing_automation_state(state_path)
    pairing_code = explicit_pairing_code
    if not pairing_code and pairing_log_path.exists():
        pairing_code = extract_latest_pairing_code(
            pairing_log_path.read_text(encoding="utf-8", errors="replace")
        )
    if not pairing_code:
        return DiscordPairingAutomationResult(pairing_code_found=False)

    bot_user_id = state.get("bot_user_id") or _fetch_bot_user_id(
        bot_token=bot_token,
        request_json=request_json,
    )
    state["bot_user_id"] = bot_user_id

    dm_channel_id = state.get("dm_channel_id") or _ensure_dm_channel(
        automation_token=automation_token,
        bot_user_id=bot_user_id,
        request_json=request_json,
    )
    state["dm_channel_id"] = dm_channel_id

    pair_command_sent = False
    pairing_code_sha256 = _pairing_code_sha256(pairing_code)
    if state.get("last_pair_code_sha256") != pairing_code_sha256:
        message_id = _send_message(
            automation_token=automation_token,
            channel_id=dm_channel_id,
            content=f"!pair {pairing_code}",
            request_json=request_json,
        )
        state["last_pair_code_sha256"] = pairing_code_sha256
        state["last_pair_command_at"] = now_timestamp()
        state["last_pair_command_message_id"] = message_id
        pair_command_sent = True

    resource_reply_sent = False
    prompt_message_id = _latest_resource_prompt_message_id(
        _fetch_recent_messages(
            automation_token=automation_token,
            channel_id=dm_channel_id,
            request_json=request_json,
        ),
        bot_user_id=bot_user_id,
        resource_prompt_regex=resource_prompt_regex,
    )
    if prompt_message_id and state.get("last_resource_prompt_message_id") != prompt_message_id:
        reply_message_id = _send_message(
            automation_token=automation_token,
            channel_id=dm_channel_id,
            content=resource_reply,
            request_json=request_json,
        )
        state["last_resource_prompt_message_id"] = prompt_message_id
        state["last_resource_reply_at"] = now_timestamp()
        state["last_resource_reply_message_id"] = reply_message_id
        resource_reply_sent = True

    save_pairing_automation_state(state_path, state)
    return DiscordPairingAutomationResult(
        pairing_code_found=True,
        pair_command_sent=pair_command_sent,
        resource_reply_sent=resource_reply_sent,
        dm_channel_id=dm_channel_id,
        bot_user_id=bot_user_id,
    )
