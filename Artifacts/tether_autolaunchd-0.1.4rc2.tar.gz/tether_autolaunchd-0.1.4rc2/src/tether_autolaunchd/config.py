from __future__ import annotations

import os
import re
import socket
from dataclasses import dataclass
from pathlib import Path

from platformdirs import user_config_dir, user_state_dir

AUTO_PLATFORM_NAMES = ("discord", "slack")
DEFAULT_ENV_FILES = (
    "~/.env",
    "~/.ENV",
    "~/.config/tether/config.env",
    "~/subprojects/tether/.env",
    "~/subprojects/tether/.ENV",
    "~/.config/tether-autolaunchd/config.env",
)


def _parse_bool(raw: str, name: str) -> bool:
    lowered = raw.strip().lower()
    if lowered in {"1", "true", "yes", "on"}:
        return True
    if lowered in {"0", "false", "no", "off"}:
        return False
    raise ValueError(f"{name} must be a boolean-like value")


def _parse_positive_int(raw: str, name: str) -> int:
    value = int(raw)
    if value <= 0:
        raise ValueError(f"{name} must be > 0")
    return value


def _parse_csv(raw: str) -> tuple[str, ...]:
    return tuple(item.strip() for item in raw.split(",") if item.strip())


def _parse_env_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        if "=" not in line:
            continue
        key, raw_value = line.split("=", 1)
        key = key.strip()
        if not key:
            continue
        value = raw_value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            value = value[1:-1]
        values.setdefault(key, value)
    return values


def _load_env_files(paths: tuple[Path, ...]) -> dict[str, str]:
    merged_values: dict[str, str] = {}
    for path in paths:
        for key, value in _parse_env_file(path).items():
            merged_values.setdefault(key, value)
    return merged_values


def _merge_config_values(
    env: dict[str, str] | None = None,
    env_file_paths: tuple[Path, ...] | None = None,
) -> tuple[dict[str, str], tuple[Path, ...]]:
    process_values = dict(os.environ if env is None else env)
    configured_env_files = env_file_paths
    if configured_env_files is None:
        raw_paths = process_values.get("TAD_ENV_FILES")
        if raw_paths is None:
            bootstrap_env_files = tuple(Path(raw).expanduser() for raw in DEFAULT_ENV_FILES)
            discovered_values = _load_env_files(bootstrap_env_files)
            raw_paths = discovered_values.get("TAD_ENV_FILES", ",".join(DEFAULT_ENV_FILES))
        configured_env_files = tuple(Path(raw).expanduser() for raw in _parse_csv(raw_paths))
    merged_values = _load_env_files(configured_env_files)
    merged_values.update(process_values)
    return merged_values, configured_env_files


def _discord_bot_token(values: dict[str, str]) -> str:
    return values.get("DISCORD_BOT_TOKEN", "").strip() or values.get("DISCORD_TOKEN", "").strip()


def _parse_discord_machine_channel_create(values: dict[str, str]) -> bool:
    raw = values.get("TAD_DISCORD_MACHINE_CHANNEL_CREATE")
    if raw is None or not raw.strip():
        return bool(
            _discord_bot_token(values)
            and values.get("DISCORD_GUILD_ID", "").strip()
            and not values.get("DISCORD_CHANNEL_ID", "").strip()
        )
    return _parse_bool(raw, "TAD_DISCORD_MACHINE_CHANNEL_CREATE")


def _discord_require_pairing(values: dict[str, str]) -> bool:
    raw = values.get("DISCORD_REQUIRE_PAIRING", "false")
    return _parse_bool(raw, "DISCORD_REQUIRE_PAIRING")


def _parse_discord_pairing_automation(values: dict[str, str]) -> bool:
    raw = values.get("TAD_DISCORD_PAIRING_AUTOMATION")
    if raw is None or not raw.strip():
        return bool(
            _discord_require_pairing(values)
            and _discord_bot_token(values)
            and values.get("TAD_DISCORD_PAIRING_AUTOMATION_TOKEN", "").strip()
        )
    return _parse_bool(raw, "TAD_DISCORD_PAIRING_AUTOMATION")


def _has_discord_credentials(values: dict[str, str]) -> bool:
    if values.get("DISCORD_TOKEN", "").strip():
        return True
    if values.get("DISCORD_BOT_TOKEN", "").strip() and values.get("DISCORD_CHANNEL_ID", "").strip():
        return True
    return bool(
        _parse_discord_machine_channel_create(values)
        and _discord_bot_token(values)
        and values.get("DISCORD_GUILD_ID", "").strip()
    )


def _detect_available_platforms(values: dict[str, str]) -> tuple[str, ...]:
    available: list[str] = []
    if _has_discord_credentials(values):
        available.append("discord")
    if values.get("SLACK_BOT_TOKEN", "").strip():
        available.append("slack")
    return tuple(available)


def _parse_platform_mode(raw: str | None, platform: str | None) -> str:
    if raw is None or not raw.strip():
        return "fixed" if platform else "auto"
    mode = raw.strip().lower()
    if mode not in {"off", "fixed", "auto"}:
        raise ValueError("TAD_PLATFORM_MODE must be one of: off, fixed, auto")
    return mode


def _parse_platform_preference(raw: str) -> tuple[str, ...]:
    platforms = _parse_csv(raw)
    if not platforms:
        raise ValueError("TAD_PLATFORM_PREFERENCE must contain at least one platform")
    invalid = [platform for platform in platforms if platform not in AUTO_PLATFORM_NAMES]
    if invalid:
        raise ValueError("TAD_PLATFORM_PREFERENCE only supports discord,slack in v1")
    deduped: list[str] = []
    seen: set[str] = set()
    for platform in platforms:
        if platform not in seen:
            seen.add(platform)
            deduped.append(platform)
    return tuple(deduped)


@dataclass(frozen=True)
class AppConfig:
    tether_bin: str
    state_dir: Path
    poll_seconds: int
    command_timeout_seconds: int
    tether_host: str
    tether_port: int
    tether_dev: bool
    start_tether: bool
    platform_mode: str
    platform: str | None
    platform_preference: tuple[str, ...]
    available_platforms: tuple[str, ...]
    runner_types: tuple[str, ...]
    seen_sessions_file: Path
    session_state_file: Path
    log_file: Path
    decision_log_file: Path
    failure_digest_file: Path
    status_snapshot_file: Path
    config_env_path: Path
    env_files: tuple[Path, ...]
    discord_bot_token: str | None
    discord_require_pairing: bool
    discord_pairing_code: str | None
    discord_guild_id: str | None
    discord_channel_id: str | None
    discord_machine_channel_create: bool
    discord_machine_channel_prefix: str
    discord_machine_name: str
    discord_machine_channel_category_id: str | None
    discord_pairing_automation_enabled: bool
    discord_pairing_automation_token: str | None
    discord_pairing_log_path: Path
    discord_pairing_state_file: Path
    discord_pairing_resources_prompt_regex: str
    discord_pairing_resources_reply: str
    runtime_env: dict[str, str]


def load_config(
    env: dict[str, str] | None = None,
    env_file_paths: tuple[Path, ...] | None = None,
) -> AppConfig:
    values, configured_env_files = _merge_config_values(env=env, env_file_paths=env_file_paths)
    state_dir = Path(values.get("TAD_STATE_DIR", user_state_dir("tether-autolaunchd"))).expanduser()
    config_dir = Path(user_config_dir("tether-autolaunchd")).expanduser()
    poll_seconds = _parse_positive_int(values.get("TAD_POLL_SECONDS", "10"), "TAD_POLL_SECONDS")
    command_timeout_seconds = _parse_positive_int(
        values.get("TAD_COMMAND_TIMEOUT_SECONDS", "60"),
        "TAD_COMMAND_TIMEOUT_SECONDS",
    )
    tether_port = _parse_positive_int(values.get("TAD_TETHER_PORT", "8787"), "TAD_TETHER_PORT")
    tether_dev = _parse_bool(values.get("TAD_TETHER_DEV", "false"), "TAD_TETHER_DEV")
    start_tether = _parse_bool(values.get("TAD_START_TETHER", "true"), "TAD_START_TETHER")
    platform = values.get("TAD_PLATFORM")
    normalized_platform = platform.strip() if platform and platform.strip() else None
    platform_mode = _parse_platform_mode(values.get("TAD_PLATFORM_MODE"), normalized_platform)
    platform_preference = _parse_platform_preference(
        values.get("TAD_PLATFORM_PREFERENCE", ",".join(AUTO_PLATFORM_NAMES))
    )
    runner_types = _parse_csv(values.get("TAD_RUNNER_TYPES", "codex,claude,opencode,pi"))
    if not runner_types:
        raise ValueError("TAD_RUNNER_TYPES must contain at least one runner type")
    discord_bot_token = _discord_bot_token(values) or None
    discord_require_pairing = _discord_require_pairing(values)
    discord_pairing_code = values.get("DISCORD_PAIRING_CODE", "").strip() or None
    discord_guild_id = values.get("DISCORD_GUILD_ID", "").strip() or None
    discord_channel_id = values.get("DISCORD_CHANNEL_ID", "").strip() or None
    discord_machine_channel_create = _parse_discord_machine_channel_create(values)
    if discord_machine_channel_create and (not discord_bot_token or not discord_guild_id):
        raise ValueError(
            "TAD_DISCORD_MACHINE_CHANNEL_CREATE requires "
            "DISCORD_BOT_TOKEN or DISCORD_TOKEN and DISCORD_GUILD_ID"
        )
    discord_machine_channel_prefix = (
        values.get("TAD_DISCORD_MACHINE_CHANNEL_PREFIX", "").strip() or "🖥️"
    )
    discord_machine_name = (
        values.get("TAD_DISCORD_MACHINE_NAME", "").strip() or socket.gethostname()
    )
    discord_machine_channel_category_id = (
        values.get("TAD_DISCORD_MACHINE_CHANNEL_CATEGORY_ID", "").strip() or None
    )
    discord_pairing_automation_enabled = _parse_discord_pairing_automation(values)
    discord_pairing_automation_token = (
        values.get("TAD_DISCORD_PAIRING_AUTOMATION_TOKEN", "").strip() or None
    )
    if discord_pairing_automation_enabled and not discord_require_pairing:
        raise ValueError("TAD_DISCORD_PAIRING_AUTOMATION requires DISCORD_REQUIRE_PAIRING=true")
    if discord_pairing_automation_enabled and not discord_bot_token:
        raise ValueError(
            "TAD_DISCORD_PAIRING_AUTOMATION requires DISCORD_BOT_TOKEN or DISCORD_TOKEN"
        )
    if discord_pairing_automation_enabled and not discord_pairing_automation_token:
        raise ValueError(
            "TAD_DISCORD_PAIRING_AUTOMATION requires TAD_DISCORD_PAIRING_AUTOMATION_TOKEN"
        )
    discord_pairing_log_path = Path(
        values.get("TAD_DISCORD_PAIRING_LOG_PATH", str(state_dir / "tether-autolaunchd.log"))
    ).expanduser()
    discord_pairing_state_file = state_dir / "discord-pairing-automation.json"
    discord_pairing_resources_prompt_regex = (
        values.get(
            "TAD_DISCORD_PAIRING_RESOURCES_PROMPT_REGEX",
            r"(?i)resources.*maintaining this session",
        ).strip()
        or r"(?i)resources.*maintaining this session"
    )
    re.compile(discord_pairing_resources_prompt_regex)
    discord_pairing_resources_reply = (
        values.get("TAD_DISCORD_PAIRING_RESOURCES_REPLY", "").strip() or "yes"
    )
    return AppConfig(
        tether_bin=values.get("TAD_TETHER_BIN", "tether"),
        state_dir=state_dir,
        poll_seconds=poll_seconds,
        command_timeout_seconds=command_timeout_seconds,
        tether_host=values.get("TAD_TETHER_HOST", "127.0.0.1"),
        tether_port=tether_port,
        tether_dev=tether_dev,
        start_tether=start_tether,
        platform_mode=platform_mode,
        platform=normalized_platform,
        platform_preference=platform_preference,
        available_platforms=_detect_available_platforms(values),
        runner_types=runner_types,
        seen_sessions_file=state_dir / "seen_sessions.txt",
        session_state_file=state_dir / "sessions.json",
        log_file=state_dir / "tether-autolaunchd.log",
        decision_log_file=state_dir / "decision-log.jsonl",
        failure_digest_file=state_dir / "failure-digest.json",
        status_snapshot_file=state_dir / "status-snapshot.json",
        config_env_path=config_dir / "config.env",
        env_files=configured_env_files,
        discord_bot_token=discord_bot_token,
        discord_require_pairing=discord_require_pairing,
        discord_pairing_code=discord_pairing_code,
        discord_guild_id=discord_guild_id,
        discord_channel_id=discord_channel_id,
        discord_machine_channel_create=discord_machine_channel_create,
        discord_machine_channel_prefix=discord_machine_channel_prefix,
        discord_machine_name=discord_machine_name,
        discord_machine_channel_category_id=discord_machine_channel_category_id,
        discord_pairing_automation_enabled=discord_pairing_automation_enabled,
        discord_pairing_automation_token=discord_pairing_automation_token,
        discord_pairing_log_path=discord_pairing_log_path,
        discord_pairing_state_file=discord_pairing_state_file,
        discord_pairing_resources_prompt_regex=discord_pairing_resources_prompt_regex,
        discord_pairing_resources_reply=discord_pairing_resources_reply,
        runtime_env=values,
    )
