"""Docker integration helpers for mocked and live Tether harnesses.

>>> from pathlib import Path
>>> config = load_docker_integration_config(env={}, workspace_dir=Path("/tmp/tad"))
>>> config.mock_mode
True
>>> config.compose_file.name
'docker-compose.mock.yml'
>>> _parse_bool("yes", "FLAG")
True
>>> _parse_csv(" codexA , openB ")
('codexA', 'openB')
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _parse_bool(raw: str, name: str) -> bool:
    lowered = raw.strip().lower()
    if lowered in {"1", "true", "yes", "on"}:
        return True
    if lowered in {"0", "false", "no", "off"}:
        return False
    raise ValueError(f"{name} must be a boolean-like value")


def _default_base_image(install_deb: bool) -> str:
    """Return the safest default image for the selected integration mode.

    >>> _default_base_image(install_deb=False)
    'python:3.11-slim'
    >>> _default_base_image(install_deb=True)
    'kalilinux/kali-rolling'
    """
    return "kalilinux/kali-rolling" if install_deb else "python:3.11-slim"


def _parse_csv(raw: str) -> tuple[str, ...]:
    return tuple(part.strip() for part in raw.split(",") if part.strip())


def _yaml_single_quoted(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


@dataclass(frozen=True)
class DockerIntegrationConfig:
    project_name: str
    compose_file: Path
    base_image: str
    mock_mode: bool
    install_deb: bool
    fake_tether: bool
    fake_sessions: tuple[str, ...]
    deb_package_path: str | None
    tether_image: str | None
    tether_service_name: str
    test_service_name: str
    tether_port: int
    pytest_target: str
    workspace_dir: Path


@dataclass(frozen=True)
class DockerIntegrationPlan:
    compose_yaml: str
    prepare_command: tuple[str, ...]
    test_command: tuple[str, ...]
    teardown_command: tuple[str, ...]
    mock_mode: bool


def _real_test_command(config: DockerIntegrationConfig) -> str:
    """Build the container test command for the live integration path.

    >>> from pathlib import Path
    >>> cfg = load_docker_integration_config(
    ...     env={
    ...         "TAD_DOCKER_MOCK": "false",
    ...         "TAD_DOCKER_TETHER_IMAGE": "ghcr.io/example/tether:test",
    ...         "TAD_DOCKER_INSTALL_DEB": "true",
    ...         "TAD_DOCKER_DEB_PATH": "dist/demo.deb",
    ...     },
    ...     workspace_dir=Path("/tmp/tad"),
    ... )
    >>> "dpkg -i /workspace/dist/demo.deb" in _real_test_command(cfg)
    True
    """
    commands: list[str] = []
    if config.install_deb:
        package_path = config.deb_package_path or "dist/tether-autolaunchd.deb"
        commands.extend(
            [
                "apt-get update",
                "DEBIAN_FRONTEND=noninteractive apt-get install -y "
                "python3 python3-platformdirs python3-pytest systemd",
                f"dpkg -i /workspace/{package_path} || apt-get install -f -y",
                "tether-autolaunchd print-env >/tmp/tether-autolaunchd.env",
            ]
        )
    commands.append(f"pytest -q {config.pytest_target}")
    return " && ".join(commands)


def _compose_args(config: DockerIntegrationConfig) -> tuple[str, ...]:
    return (
        "docker",
        "compose",
        "--project-name",
        config.project_name,
        "--file",
        str(config.compose_file),
    )


def _test_service_environment(config: DockerIntegrationConfig) -> str:
    lines = ['      TAD_DOCKER_MOCK: "false"']
    if config.fake_tether:
        lines.extend(
            [
                '      TAD_START_TETHER: "false"',
                "      TAD_TETHER_BIN: /workspace/tests/fixtures/fake_tether_cli.py",
                f"      TAD_FAKE_TETHER_SESSIONS: {','.join(config.fake_sessions)}",
                "      TAD_FAKE_TETHER_ATTACH_LOG: /tmp/tad-attach-log.jsonl",
                "      TAD_FAKE_TETHER_SYNC_LOG: /tmp/tad-sync-log.jsonl",
            ]
        )
    else:
        lines.extend(
            [
                f"      TAD_TETHER_HOST: {config.tether_service_name}",
                f'      TAD_TETHER_PORT: "{config.tether_port}"',
            ]
        )
    return "\n".join(lines) + "\n"


def load_docker_integration_config(
    env: dict[str, str] | None = None,
    workspace_dir: Path | None = None,
) -> DockerIntegrationConfig:
    values = dict(os.environ if env is None else env)
    root = Path.cwd() if workspace_dir is None else workspace_dir
    mock_mode = _parse_bool(values.get("TAD_DOCKER_MOCK", "true"), "TAD_DOCKER_MOCK")
    install_deb = _parse_bool(
        values.get("TAD_DOCKER_INSTALL_DEB", "false"),
        "TAD_DOCKER_INSTALL_DEB",
    )
    fake_tether = _parse_bool(
        values.get("TAD_DOCKER_FAKE_TETHER", "false"),
        "TAD_DOCKER_FAKE_TETHER",
    )
    project_name = values.get("TAD_DOCKER_PROJECT", "tether-autolaunchd-itest").strip()
    if not project_name:
        raise ValueError("TAD_DOCKER_PROJECT must not be empty")
    default_compose_name = "docker-compose.mock.yml" if mock_mode else "docker-compose.real.yml"
    compose_name = values.get("TAD_DOCKER_COMPOSE_FILE", default_compose_name).strip()
    if not compose_name:
        raise ValueError("TAD_DOCKER_COMPOSE_FILE must not be empty")
    pytest_target = values.get(
        "TAD_DOCKER_PYTEST_TARGET",
        "tests/test_bdd_docker_integration.py",
    ).strip()
    if not pytest_target:
        raise ValueError("TAD_DOCKER_PYTEST_TARGET must not be empty")
    deb_package_path = values.get("TAD_DOCKER_DEB_PATH", "").strip() or None
    if install_deb and deb_package_path is None:
        raise ValueError("TAD_DOCKER_DEB_PATH must be set when TAD_DOCKER_INSTALL_DEB=true")
    tether_image = values.get("TAD_DOCKER_TETHER_IMAGE", "").strip() or None
    if not mock_mode and not fake_tether and tether_image is None:
        raise ValueError("TAD_DOCKER_TETHER_IMAGE must be set when TAD_DOCKER_MOCK=false")
    fake_sessions = _parse_csv(values.get("TAD_DOCKER_FAKE_SESSIONS", "codexA"))
    return DockerIntegrationConfig(
        project_name=project_name,
        compose_file=(root / compose_name).resolve(),
        base_image=values.get("TAD_DOCKER_BASE_IMAGE", _default_base_image(install_deb)).strip(),
        mock_mode=mock_mode,
        install_deb=install_deb,
        fake_tether=fake_tether,
        fake_sessions=fake_sessions,
        deb_package_path=deb_package_path,
        tether_image=tether_image,
        tether_service_name=values.get("TAD_DOCKER_TETHER_SERVICE", "tether").strip() or "tether",
        test_service_name=values.get("TAD_DOCKER_TEST_SERVICE", "bdd").strip() or "bdd",
        tether_port=int(values.get("TAD_DOCKER_TETHER_PORT", "8787")),
        pytest_target=pytest_target,
        workspace_dir=root.resolve(),
    )


def render_mock_compose(config: DockerIntegrationConfig) -> str:
    pytest_command = _yaml_single_quoted(f"pytest -q {config.pytest_target}")
    return (
        "services:\n"
        f"  {config.test_service_name}:\n"
        f"    image: {config.base_image}\n"
        f"    container_name: {config.project_name}-bdd\n"
        "    working_dir: /workspace\n"
        '    entrypoint: ["/bin/sh", "-lc"]\n'
        f"    command: [{pytest_command}]\n"
        "    environment:\n"
        f'      TAD_DOCKER_MOCK: "{"true" if config.mock_mode else "false"}"\n'
        "    volumes:\n"
        f"      - {config.workspace_dir}:/workspace:ro\n"
    )


def render_real_compose(config: DockerIntegrationConfig) -> str:
    tether_image = config.tether_image or "tether:latest"
    test_command = _yaml_single_quoted(_real_test_command(config))
    tether_service = ""
    depends_on = ""
    if not config.fake_tether:
        tether_service = (
            f"  {config.tether_service_name}:\n"
            f"    image: {tether_image}\n"
            "    command: >-\n"
            f"      start --host 0.0.0.0 --port {config.tether_port}\n"
            "    ports:\n"
            f'      - "{config.tether_port}:{config.tether_port}"\n'
        )
        depends_on = f"    depends_on:\n      - {config.tether_service_name}\n"
    return (
        "services:\n"
        f"{tether_service}"
        f"  {config.test_service_name}:\n"
        f"    image: {config.base_image}\n"
        f"    container_name: {config.project_name}-bdd\n"
        f"{depends_on}"
        "    working_dir: /workspace\n"
        '    entrypoint: ["/bin/sh", "-lc"]\n'
        f"    command: [{test_command}]\n"
        "    environment:\n"
        f"{_test_service_environment(config)}"
        "    volumes:\n"
        f"      - {config.workspace_dir}:/workspace:rw\n"
    )


def plan_mock_docker_bdd(config: DockerIntegrationConfig) -> DockerIntegrationPlan:
    compose_args = _compose_args(config)
    return DockerIntegrationPlan(
        compose_yaml=render_mock_compose(config),
        prepare_command=compose_args + ("config",),
        test_command=("pytest", "-q", config.pytest_target),
        teardown_command=compose_args + ("down", "--volumes"),
        mock_mode=config.mock_mode,
    )


def plan_real_docker_bdd(config: DockerIntegrationConfig) -> DockerIntegrationPlan:
    compose_args = _compose_args(config)
    return DockerIntegrationPlan(
        compose_yaml=render_real_compose(config),
        prepare_command=compose_args + ("config",),
        test_command=compose_args
        + (
            "up",
            "--build",
            "--abort-on-container-exit",
            "--exit-code-from",
            config.test_service_name,
        ),
        teardown_command=compose_args + ("down", "--volumes"),
        mock_mode=config.mock_mode,
    )


def direct_real_docker_bdd_command(config: DockerIntegrationConfig) -> tuple[str, ...]:
    """Build a single-container Docker command for fake-Tether live runs.

    This keeps the installed-package smoke test runnable on hosts that have
    Docker but lack Docker Compose support.
    """
    if config.mock_mode:
        raise ValueError("direct_real_docker_bdd_command requires live mode")
    if not config.fake_tether:
        raise ValueError("direct_real_docker_bdd_command requires TAD_DOCKER_FAKE_TETHER=true")

    command = [
        "docker",
        "run",
        "--rm",
        "--name",
        f"{config.project_name}-bdd",
        "--workdir",
        "/workspace",
        "--volume",
        f"{config.workspace_dir}:/workspace:rw",
        "--env",
        "TAD_DOCKER_MOCK=false",
        "--env",
        "TAD_START_TETHER=false",
        "--env",
        "TAD_TETHER_BIN=/workspace/tests/fixtures/fake_tether_cli.py",
        "--env",
        f"TAD_FAKE_TETHER_SESSIONS={','.join(config.fake_sessions)}",
        "--env",
        "TAD_FAKE_TETHER_ATTACH_LOG=/tmp/tad-attach-log.jsonl",
        "--env",
        "TAD_FAKE_TETHER_SYNC_LOG=/tmp/tad-sync-log.jsonl",
        config.base_image,
        "/bin/sh",
        "-lc",
        _real_test_command(config),
    ]
    return tuple(command)


def plan_docker_bdd(config: DockerIntegrationConfig) -> DockerIntegrationPlan:
    if config.mock_mode:
        return plan_mock_docker_bdd(config)
    return plan_real_docker_bdd(config)
