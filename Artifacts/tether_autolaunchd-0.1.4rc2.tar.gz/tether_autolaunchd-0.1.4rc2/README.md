# tether-autolaunchd

[![CI](https://github.com/realagiorganization/tether-autolaunchd/actions/workflows/ci.yml/badge.svg)](https://github.com/realagiorganization/tether-autolaunchd/actions/workflows/ci.yml)
[![Release](https://github.com/realagiorganization/tether-autolaunchd/actions/workflows/release.yml/badge.svg)](https://github.com/realagiorganization/tether-autolaunchd/actions/workflows/release.yml)

`tether-autolaunchd` is a small CLI and systemd user-service scaffold for automatically keeping Tether available on a machine, auto-attaching newly discovered local agent sessions, and continuously syncing already-attached sessions back into Tether.

The scope is intentionally narrow:

- local machine only
- environment-driven configuration
- auto-attach for sessions already discoverable by `tether list --external`
- Kali-friendly systemd user-service packaging

Explicitly out of scope in this scaffold:

- flexible fleet orchestration
- cloud-hosted machine management

## What it does

- starts `tether start` if the local Tether API is not healthy
- polls discoverable external sessions from Tether
- auto-attaches sessions that are not yet attached for the current resolved platform
- syncs every detected session that is already attached for the current resolved platform
- resolves one messaging platform per pass in `off`, `fixed`, or `auto` mode
- keeps a local JSON state file with per-session attach metadata plus the bound Tether session id used for follow-up sync passes

## Current roadmap notes

- Docker integration coverage is mocked-first right now.
- The mocked scaffold is intentionally deterministic and does not require a live Docker daemon.
- The real Docker/Tether integration path now exists as an explicit opt-in command and remains disabled by default.
- A Kali package-install integration path now exists for `.deb` smoke coverage and remains opt-in.
- Full planned package-level scenarios are recorded as disabled tests until a stable live Tether fixture is available.

## README demo

The demo below is rendered from `tapes/bdd-demo.tape` and refreshed in GitHub Actions by installing `ttyd` plus `vhs` on the runner and calling the repo-native `make bdd-vhs` target.

![tether-autolaunchd BDD demo](docs/tether-autolaunchd-bdd-demo.gif)
[![tether-autolaunchd feature tour](docs/tether-autolaunchd-docs-site.png)](https://realagiorganization.github.io/tether-autolaunchd/)
Live feature tour: `https://realagiorganization.github.io/tether-autolaunchd/`
[![tether-autolaunchd feature tour on iPad Safari](docs/tether-autolaunchd-docs-site-ipad.png)](https://realagiorganization.github.io/tether-autolaunchd/)
Real iPad Safari capture: iPad mini (6th generation), iPadOS 18.5.

## CLI

```bash
tether-autolaunchd once
tether-autolaunchd daemon
tether-autolaunchd print-user-unit
tether-autolaunchd print-env
tether-autolaunchd print-status-json
```

## Published packages

- Homebrew tap: `brew tap realagiorganization/tap && brew install tether-autolaunchd`
- Kali apt repo stable: `KEYRING=/usr/share/keyrings/tether-autolaunchd-archive-keyring.gpg && REPO_ROOT=https://raw.githubusercontent.com/realagiorganization/tether-autolaunchd-apt/main && curl -fsSL "${REPO_ROOT}/tether-autolaunchd-archive-keyring.gpg" | sudo tee "${KEYRING}" >/dev/null && echo "deb [signed-by=${KEYRING}] ${REPO_ROOT}/stable ./" | sudo tee /etc/apt/sources.list.d/tether-autolaunchd.list && sudo apt-get update && sudo apt-get install tether-autolaunchd`
- Kali apt repo release candidates: `KEYRING=/usr/share/keyrings/tether-autolaunchd-archive-keyring.gpg && REPO_ROOT=https://raw.githubusercontent.com/realagiorganization/tether-autolaunchd-apt/main && curl -fsSL "${REPO_ROOT}/tether-autolaunchd-archive-keyring.gpg" | sudo tee "${KEYRING}" >/dev/null && echo "deb [signed-by=${KEYRING}] ${REPO_ROOT}/rc ./" | sudo tee /etc/apt/sources.list.d/tether-autolaunchd-rc.list && sudo apt-get update && sudo apt-get install tether-autolaunchd`

## Environment and platform policy

- `TAD_TETHER_BIN`: path to the `tether` CLI, default `tether`
- `TAD_STATE_DIR`: state/log directory, default platformdirs user-state path
- `TAD_POLL_SECONDS`: daemon poll interval, default `10`
- `TAD_COMMAND_TIMEOUT_SECONDS`: max seconds for each spawned `tether list`, `tether attach`, or `tether sync` command before the daemon abandons that call and continues, default `60`
- `TAD_TETHER_HOST`: local Tether bind host, default `127.0.0.1`
- `TAD_TETHER_PORT`: local Tether bind port, default `8787`
- `TAD_TETHER_DEV`: start Tether with `--dev`, default `false`
- `TAD_START_TETHER`: start Tether automatically if health check fails, default `true`
- `TAD_PLATFORM_MODE`: `off`, `fixed`, or `auto`; defaults to `fixed` when `TAD_PLATFORM` is set, otherwise `auto`
- `TAD_PLATFORM`: explicit fixed platform passed to `tether attach -p`; keeps backward compatibility with existing fixed targets such as `telegram`
- `TAD_PLATFORM_PREFERENCE`: comma-separated preference order for auto mode, default `discord,slack`
- `TAD_ENV_FILES`: ordered env files loaded after process env precedence, default `~/.env,~/.ENV,~/.config/tether/config.env,~/subprojects/tether/.env,~/subprojects/tether/.ENV,~/.config/tether-autolaunchd/config.env`
- when those watched env files do not already set a default adapter, Android/Termux launches inject `TETHER_DEFAULT_AGENT_ADAPTER=opencode` before starting managed Tether
- `DISCORD_TOKEN`: enables `discord` as an auto-mode target when non-empty
- `DISCORD_BOT_TOKEN` plus `DISCORD_CHANNEL_ID`: also enable `discord` auto-mode when using Tether's native Discord bridge variables
- `DISCORD_BOT_TOKEN` plus `DISCORD_GUILD_ID`: enable per-machine Discord control-channel bootstrap when `DISCORD_CHANNEL_ID` is unset
- `TAD_DISCORD_MACHINE_CHANNEL_CREATE`: force or disable machine-channel bootstrap; default is auto-enabled when a Discord bot token and guild id exist and `DISCORD_CHANNEL_ID` is empty, and explicit `true` overrides any inherited fixed `DISCORD_CHANNEL_ID`
- `TAD_DISCORD_MACHINE_CHANNEL_PREFIX`: channel-name prefix, default `🖥️`
- `TAD_DISCORD_MACHINE_NAME`: machine label used in the channel name; defaults to the local hostname
- `TAD_DISCORD_MACHINE_CHANNEL_CATEGORY_ID`: optional Discord category id for the created machine channel
- `DISCORD_REQUIRE_PAIRING`: tell the launcher that the Discord bridge expects DM-based pairing before commands are accepted
- `DISCORD_PAIRING_CODE`: optional fixed pairing code; when unset, the launcher can read the generated code back from the local Tether log
- `TAD_DISCORD_PAIRING_AUTOMATION`: enable DM-based pairing automation; defaults to auto when pairing is required and `TAD_DISCORD_PAIRING_AUTOMATION_TOKEN` is set
- `TAD_DISCORD_PAIRING_AUTOMATION_TOKEN`: Discord automation credential used to DM the Tether bot `!pair <code>`
- `TAD_DISCORD_PAIRING_LOG_PATH`: optional override for the local log file that contains the `code=...` pairing line; defaults to the launcher log
- `TAD_DISCORD_PAIRING_RESOURCES_PROMPT_REGEX`: regex for the post-pairing resource-check prompt, default `(?i)resources.*maintaining this session`
- `TAD_DISCORD_PAIRING_RESOURCES_REPLY`: reply sent once when that prompt appears, default `yes`
- `SLACK_BOT_TOKEN`: enables `slack` as an auto-mode target when non-empty
- `TAD_RUNNER_TYPES`: comma-separated runner types to scan, default `codex,claude,opencode,pi`

In `auto` mode the daemon uses presence-only credential detection for Slack and fixed Discord channel ids. If Discord machine-channel bootstrap is enabled, it resolves or creates a machine-named Discord text channel before launching Tether, injects the resulting `DISCORD_CHANNEL_ID` into the managed runtime env, and then attaches sessions with `-p discord`. The daemon reloads config on every poll pass so env-file changes are picked up without restarting the service.

On Android/Termux, that same runtime bootstrap also defaults managed Tether to
`opencode` when no adapter is configured yet, so reaction shortcuts and newly
created sessions do not fall back to a desktop-only Codex path.

## Discord machine channels

When `DISCORD_GUILD_ID` is set and `DISCORD_CHANNEL_ID` is left empty, `tether-autolaunchd` can create one control channel per machine automatically. The default channel name is `<emoji-prefix>-<hostname-slug>`, for example `🖥️-kali-thinkpad1`. Existing matching channels are reused instead of recreated.

If a shared `.env` or inherited systemd environment still contains a stale `DISCORD_CHANNEL_ID`, set `TAD_DISCORD_MACHINE_CHANNEL_CREATE=true` and the launcher will override that fixed id at runtime with the machine-specific channel it resolved for the current host.

The created channel becomes Tether's Discord control channel for that machine, so new `tether attach -p discord` operations land in machine-scoped Discord threads under a stable per-host home.

## Discord pairing automation

When the Discord bridge is configured with `DISCORD_REQUIRE_PAIRING=true`, Tether logs a warning that includes the active pairing code. `tether-autolaunchd` can optionally automate that DM flow:

- read the latest pairing code from the local launcher log, or fall back to `DISCORD_PAIRING_CODE`
- open or reuse a DM with the Tether bot by using `TAD_DISCORD_PAIRING_AUTOMATION_TOKEN`
- send `!pair <code>` once per unique pairing code
- watch the DM for a follow-up prompt about system resources and answer it once with `TAD_DISCORD_PAIRING_RESOURCES_REPLY`, default `yes`

This stays opt-in and explicit. The automation does nothing unless pairing is required and a separate pairing automation token is configured.

## State files

- `sessions.json`: primary JSON state store with `attached_platform`, `attach_status`, `tether_session_id`, and timestamps per session
- `seen_sessions.txt`: compatibility mirror of successfully attached session IDs
- `decision-log.jsonl`: append-only per-pass and per-session decision log for attach, sync, skip, and runner failure events
- `failure-digest.json`: rolling counters and the latest failure details for self-heal, attach, and sync behavior
- `status-snapshot.json`: latest machine-readable status snapshot exposed by `tether-autolaunchd print-status-json`

## Development

```bash
make install-dev
make lint
make policy
make lint-workflows
make test
make test-cov
make bdd
make bdd-vhs
make docker-bdd-prepare
TAD_DOCKER_TETHER_IMAGE=ghcr.io/example/tether:test make bdd-real
make bdd-kali-deb-prepare
TAD_DOCKER_TETHER_IMAGE=ghcr.io/example/tether:test make bdd-kali-deb-live
make ci
make build-python-dist
make build-deb
```

`make bdd-real` is opt-in. It requires both `TAD_DOCKER_REAL=true` and `TAD_DOCKER_TETHER_IMAGE=...` so the live path cannot run accidentally in CI.

`make bdd-vhs` regenerates the tracked README demo GIF locally using `vhs` only when both `vhs` and `ttyd` are available, or the official `ghcr.io/charmbracelet/vhs` container as a fallback. Remote CI installs `ttyd` plus `vhs` on the runner and then uses the same repo-native target so the committed README asset matches the workflow-rendered demo.

`make bdd-kali-deb-live` is even narrower: it installs the built `.deb` package into a Kali container before running the selected smoke test target. When Docker Compose is unavailable but Docker itself is present, the fake-Tether smoke path falls back to a single `docker run`.

The test suite also runs doctests from Python modules, and linting now includes a strict McCabe complexity gate plus repository-wide line-count limits for Python, Make, Markdown, YAML, feature, and tape files.

## GitHub Actions packaging

The standalone repository uses:

- `.github/workflows/ci.yml` for lint, workflow verification, repository policy checks, tests, coverage, Python build artifacts, and `.deb` packaging
- `.github/workflows/release.yml` for tagged GitHub Release publishing of wheel, sdist, and `.deb` artifacts plus mirrored publication into `realagiorganization/homebrew-tap` and `realagiorganization/tether-autolaunchd-apt`

The main local verification command is:

```bash
make ci
```

The cross-repo publish step expects:

- `PUBLISH_REPO_TOKEN` with write access to the tap and apt repositories
- `APT_REPO_GPG_PRIVATE_KEY` containing the armored private key for the apt archive
- `APT_REPO_GPG_PASSPHRASE` containing the passphrase for that key

## Env files

`.env` is gitignored for local secrets. `.env.sample` is committed with masked Discord-related placeholders and safe defaults for the local Tether scaffold.
